#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char gj[10];
char * sq = gj;

void main() 
{
	char * gsx;
	gsx	= gj;
	int x = 'a';
	char y = x;

	char *a = malloc(sizeof(char)*6);
	strcpy(a, "hello");

	printf("%s\n", a);

	int c;
	c = *a;

	char *b;
	for (b = a; *b != 0; b++)
		printf("%c: %d\n", *b, *b);

	char destarray[10];
	char *dest = destarray;
	char *src = a;

	while (*src != 0)
		*dest++ = *src++;

	*dest = 0;

	printf("copied string is %s\n", destarray);
}
