/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xmlstructure;

import java.awt.Component;

/**
 * Objet contenant les informations sur l'affichage d'un message récupéré en flux de sortie
 * @author mahamat
 */
public class Message extends Instruction {
    /**
     * Message récuperer en flux de sortie
     */
    private final String message;
    
    /**
     * Constructeur de l'objet
     * @param ident Identifiant de l'instruction
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param message Message récupéré
     */
    public Message(String ident, String ligne, String fichier, String message) {
        super(ident, ligne, fichier);
        this.message = message;
    }

    /**
     * Renvoi un message
     * @return Message
     */
    public String getMessage() {
        return message;
    }
    
     @Override
    public enumType getTypeInstruction() {
        return enumType.eTypeMessage;
    }

    @Override
    public Component produireComposant() {
        return null;
    }
    
}
