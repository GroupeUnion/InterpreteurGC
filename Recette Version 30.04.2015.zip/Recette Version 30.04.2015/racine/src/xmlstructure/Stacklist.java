package xmlstructure;

import interpreteurgraphic.ArrayFigure;
import interpreteurgraphic.Composant;
import interpreteurgraphic.FonctionFigure;
import interpreteurgraphic.OperationClass.OperationAdapter;
import interpreteurgraphic.OperationClass.OperationListener;
import interpreteurgraphic.WrapLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

/**
 * Objet contenant les informations sur tout bloc d'instructions
 *
 * @author mahamat
 */
public class Stacklist extends Instruction {

    /**
     * Nom de la stacklist
     */
    private String nom;
    
    /**
     * Type de la stacklist
     */
    private String type;
    
    /**
     * Typeid de la stakcklist (function, for, ...)
     */
    private String typeid;
    
    /**
     * Variable de retour d'une function ou variable de fin d'un stacklist
     */
    private Variable retour;
    
    /**
     * Liste des instructions de la stacklist
     */
    private List<Instruction> list;
    
    /**
     * Liste des paremètres d'une function
     */
    private List<Variable> param;
    
    /**
     * Objet graphique représentant le bloc d'instruction
     */
    private Container composant;

    /**
     * Constructeur de la stacklist
     * @param id Identifiant de l'instruction
     * @param retour Variable de retour ou de fin de la stacklist
     * @param param Liste des variables en paramètre d'une function
     * @param list Liste des instructions d'une stacklist
     * @param type Type d'une stacklist
     * @param typeid TypeId d'une stacklist
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param nom Nom de la stacklist
     */
    public Stacklist(String id, Variable retour, List<Variable> param, List<Instruction> list,
            String type, String typeid, String ligne, String fichier, String nom) {
        super(id, ligne, fichier);
        this.retour = retour;
        this.type = type;
        this.list = list;
        this.param = param;
        this.typeid = typeid;
        this.nom = nom;
        switch (enumType.getTypeOf(this.typeid)) {
            case eTypeFonction:
                if (param.isEmpty()) {
                    this.nom += "()";
                } else {
                    this.nom += "(" + param.get(0).getType() + " " + param.get(0).getNom();
                    for (int i = 1; i < param.size(); i++) {
                        Variable variable = param.get(i);
                        this.nom += ", " + variable.getType() + " " + variable.getNom();
                    }
                    this.nom += ")";
                }
                break;
            default:
                this.type = "stacklist";
                this.nom = this.typeid;
                break;
        }
    }
    
    @Override
    public Component produireComposant() {
        if (composant == null) {
            Composant composantGlobale = new Composant("");
            composantGlobale.setLayout(new GridBagLayout());
            composantGlobale.setMargin(0, 0, 0, 0);
            Container mainBloc = produireComposant(composantGlobale);
            mainBloc.setVisible(true);
            composant = composantGlobale;
        }
        return composant;
    }
    
    /**
     * Créé l'objet graphique contenant l'ensemble de enchainement des appels de fonctions
     * @param composantGlobale Objet graphique contenant une succesion de fonction
     * @return Objet graphique contenant l'ensemble de enchainement des appels de fonctions
     */

    private Container produireComposant(Composant composantGlobale) {
        if (composant == null) {
            Stacklist bloc;
            OperationAdapter op;
            Component cResult;
            composant = new FonctionFigure(type + " " + nom);
            composant.setLayout(new WrapLayout(WrapLayout.LEFT));
            switch (enumType.getTypeOf(typeid)) {
                case eTypeFonction: {
                    Composant composant_param;
                    GridBagConstraints constraint = new GridBagConstraints(1, -1, 1, 1, 0, 0, 10,
                            GridBagConstraints.VERTICAL, new Insets(40, 0, 0, 0), 0, 0);
                    composantGlobale.add(composant, constraint);
                    if (!param.isEmpty()) {
                        composant_param = new Composant("@param");
                        composant.add(composant_param);
                        for (Variable param1 : param) {
                            op = (OperationAdapter) param1.produireComposant();
                            cResult = param1.produireComposant();
                            cResult.setVisible(false);
                            op.setHaveMargin(false);
                            op.setMargin(0, 0, 0, 0);
                            op.setDeplacable(false);
                            composant_param.add(cResult);
                        }
                    }
                }
                default:
                    FonctionFigure composant_bloc;
                    if (!list.isEmpty()) {
                        for (Instruction instr : list) {
                            switch (instr.getTypeInstruction()) {
                                case eTypeAffectation:
                                case eTypeMessage:
                                    break;
                                case eTypeStacklist:
                                    bloc = (Stacklist) instr;
                                    composant_bloc = (FonctionFigure) bloc.produireComposant(composantGlobale);
                                    if (!"function".equals(bloc.typeid)) {
                                        composant.add(composant_bloc);
                                    } else {
                                        composant_bloc.addReferer(composant);
                                    }
                                    composant_bloc.setVisible(false);
                                    break;
                                case eTypePointeur:
                                    ((OperationAdapter) ((ArrayFigure) instr.produireComposant()).getPointer()).setDeplacable(false);
                                default:
                                    composant.add(instr.produireComposant());
                                    instr.produireComposant().setVisible(false);
                                    ((OperationAdapter)instr.produireComposant()).setDeplacable(false);
                                    break;
                            }
                        }
                    }
                    composant.add(retour.produireComposant());
                    retour.produireComposant().setVisible(false);
                    ((OperationAdapter) retour.produireComposant()).addOperationListener(
                            new OperationListener() {
                                @Override
                                public void setVisibility(boolean isVisible) {
                                    composant.setVisible(isVisible);
                                }
                            });
            }
        }
        return composant;
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.eTypeStacklist;
    }
}
