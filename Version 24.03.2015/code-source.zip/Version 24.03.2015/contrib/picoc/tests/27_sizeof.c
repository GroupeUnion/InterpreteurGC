#include <stdio.h>

char a;
int b;
double c;




void main() 
{
	printf("%d\n", sizeof(a));
	printf("%d\n", sizeof(b));
	printf("%d\n", sizeof(c));
}
