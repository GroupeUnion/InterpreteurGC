package interpreteurgraphic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import interpreteurgraphic.OperationClass.OperationAdapter;
import xmlstructure.Instruction;
import xmlstructure.Affectation;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import xmlstructure.Bloc;
import xmlstructure.Variable;

/**
 *
 * @author Asus
 */
public class Fenetre extends JFrame implements ComponentListener, ActionListener, AdjustmentListener {

    public static Fleche flechePanel = new Fleche();
    private SourcePanel sourcePanel;
    private final JButton buttonNext, buttonPrev;
    private int flecheNumber;
    private final JPanel mainPanel, declarationPanel;
    private final JScrollPane mainScrollPane, declarationScrollPane;
    private final List<Instruction> listInstruction;
    private final Color colorbg;

    public Fenetre(String title, int largeur, int hauteur, Map<Integer, Instruction> hashDeclaration) {
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setSize(largeur, hauteur);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.flecheNumber = 0;

        this.colorbg = Color.getHSBColor((float) (212 / 256.0), (float) (17 / 256.0), (float) (67 / 256.0));

        this.declarationPanel = new JPanel();
        this.declarationPanel.setLayout(new WrapLayout(FlowLayout.LEFT));
        this.declarationPanel.setOpaque(true);
        this.declarationPanel.setBackground(colorbg);

        this.declarationScrollPane = new JScrollPane(this.declarationPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.declarationScrollPane.setLocation(300, 15);
        this.declarationScrollPane.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        this.declarationScrollPane.getHorizontalScrollBar().addAdjustmentListener(this);
        this.declarationScrollPane.getVerticalScrollBar().addAdjustmentListener(this);

        this.mainPanel = new JPanel();
        this.mainPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        this.mainPanel.setOpaque(true);
        this.mainPanel.setBackground(colorbg);

        this.mainScrollPane = new JScrollPane(this.mainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.mainScrollPane.setOpaque(false);
        this.mainScrollPane.setLocation(300, 265);
        Border margin = BorderFactory.createMatteBorder(3, 0, 0, 0, new Color(109, 170, 193));
        Border textBorder = BorderFactory.createTitledBorder(margin, "Execution", TitledBorder.CENTER, TitledBorder.TOP, this.getFont(), Color.WHITE);
        this.mainScrollPane.setBorder(textBorder);

        this.mainScrollPane.getHorizontalScrollBar().addAdjustmentListener(this);
        this.mainScrollPane.getVerticalScrollBar().addAdjustmentListener(this);

        this.buttonNext = new JButton("Suivant");
        this.buttonNext.setSize(new Dimension(120, 25));
        this.buttonNext.addActionListener(this);

        Fenetre.flechePanel.setLocation(300, 15);

        this.buttonPrev = new JButton("Revenir");
        this.buttonPrev.setSize(new Dimension(150, 25));
        this.buttonPrev.addActionListener(this);
        this.buttonPrev.setEnabled(false);

        this.getContentPane().add(Fenetre.flechePanel);
        this.getContentPane().add(this.mainScrollPane);
        this.getContentPane().add(this.declarationScrollPane);
        this.getContentPane().add(this.buttonNext);
        this.getContentPane().add(this.buttonPrev);

        this.getContentPane().setBackground(colorbg);
        this.setVisible(true);
        this.addComponentListener(this);
        this.listInstruction = new ArrayList<Instruction>(hashDeclaration.values());

    }

    public void chargement(String fichierSource[]) {
        this.sourcePanel = new SourcePanel(fichierSource);
        this.sourcePanel.setLocation(0, 30);
        this.sourcePanel.setSize(this.mainPanel.getX(), this.getHeight());
        this.getContentPane().add(sourcePanel);
        this.sourcePanel.repaint();
        this.revalidate();

        //initialisation position fleche
        this.flecheNumber = 0;
        this.updateSourcePanel(-1, flecheNumber);
        //force la mise a jour des positionnements
        componentResized(null);
    }

    @Override
    public void componentResized(ComponentEvent e) {
        if (this.mainPanel != null) {
            this.mainScrollPane.setSize(this.getWidth() - this.mainScrollPane.getX() - 15, this.getHeight() - 300);
            this.declarationScrollPane.setSize(this.getWidth() - this.declarationScrollPane.getX() - 15, 250);
            Fenetre.flechePanel.setSize(this.getWidth() - Fenetre.flechePanel.getX(), this.getHeight());
            this.getContentPane().revalidate();
            this.getContentPane().repaint();
        }
        if (this.sourcePanel != null) {
            this.sourcePanel.setSize(this.mainScrollPane.getX() + 1, this.getHeight() - 85);
            if (this.buttonPrev != null) {
                this.buttonPrev.setLocation(this.sourcePanel.getX() + 30, (this.sourcePanel.getHeight() + 35));
            }
            if (this.buttonNext != null) {
                this.buttonNext.setLocation(this.sourcePanel.getX() + this.buttonPrev.getWidth() + 30, (this.sourcePanel.getHeight() + 35));
            }
        }
    }

    @Override
    public void componentMoved(ComponentEvent e) {
    }

    @Override
    public void componentShown(ComponentEvent e) {
    }

    @Override
    public void componentHidden(ComponentEvent e) {
    }

    private void updateSourcePanel(int idPrec, int idSuiv) {
        Instruction instructionPrec = null, instructionSuiv = null;
        if (0 <= idPrec && idPrec < listInstruction.size()) {
            instructionPrec = this.listInstruction.get(idPrec);
        }
        if (0 <= idSuiv && idSuiv < listInstruction.size()) {
            instructionSuiv = this.listInstruction.get(idSuiv);
        }
        
         this.sourcePanel.update(instructionPrec != null ? instructionPrec.getLigne() - 1: -1,
                 instructionPrec != null ? instructionPrec.getFichier() : null,
                 instructionSuiv != null ? instructionSuiv.getLigne() - 1 : -1, 
                 instructionSuiv != null ? instructionSuiv.getFichier() : null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Suivant": {
                if (showInstruction(flecheNumber)) {
                    if (!this.buttonPrev.isEnabled()) {
                        this.buttonPrev.setEnabled(true);
                    }
                    this.updateSourcePanel(flecheNumber, ++flecheNumber);
                    if (flecheNumber >= listInstruction.size()) {
                        this.buttonNext.setEnabled(false);
                        flecheNumber = listInstruction.size();
                    }
                }
                componentResized(null);
                break;
            }
            case "Revenir": {
                if (retourArriere(flecheNumber - 1)) {
                    if (!this.buttonNext.isEnabled()) {
                        this.buttonNext.setEnabled(true);
                    }
                    this.updateSourcePanel(--flecheNumber -1, flecheNumber);
                    if (flecheNumber < 0) {
                        this.buttonPrev.setEnabled(false);
                        flecheNumber = 0;
                    }
                }
                componentResized(null);
                break;
            }
        }
    }

    public boolean showInstruction(int id) {
        if (!this.listInstruction.isEmpty()) {
            Instruction instruction;
            OperationAdapter operation;
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                removeFlecheTemporaire(id - 1);
                if (instruction instanceof Affectation) {
                    ((Affectation) instruction).affect();
                }
                if (!mainPanel.isAncestorOf(instruction.produireComposant())
                        && !declarationPanel.isAncestorOf(instruction.produireComposant())) {
                    if (instruction instanceof Bloc) {
                        mainPanel.add(instruction.produireComposant());
                    } else {
                        declarationPanel.add(instruction.produireComposant());
                    }
                }
                instruction.produireComposant().setVisible(true);
                if (instruction instanceof Variable
                        && "@return".equals(((Variable) instruction).getNom())) {
                    operation = (OperationAdapter) instruction.produireComposant();
                    operation.setVisibleEvent(instruction, true);
                }
            }
            return true;
        }
        return false;
    }

    private boolean retourArriere(int id) {
        if (!this.listInstruction.isEmpty()) {
            Instruction instruction;
            OperationAdapter operation;
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                if (instruction instanceof Affectation) {
                    ((Affectation) instruction).desaffect();
                    operation = (OperationAdapter) instruction.produireComposant();
                    operation.setVisibleEvent(instruction, true);
                    //instruction.produireComposant().setVisible(false);
                    removeFlecheTemporaire(id);
                    showInstruction(id - 1);
                } else {                    
                    operation = (OperationAdapter) instruction.produireComposant();
                    operation.setVisibleEvent(instruction, true);
                    instruction.produireComposant().setVisible(false);
                    showInstruction(id - 1);
                }
                return true;
            }
        }
        return false;
    }

    public void removeFlecheTemporaire(int id) {
        if (!this.listInstruction.isEmpty()) {
            Instruction instruction;
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                if (instruction instanceof Affectation) {
                    ((Affectation) instruction).removeFlecheTemporaire();
                } else if (instruction instanceof Variable
                        && "@return".equals(((Variable) instruction).getNom())) {
                    instruction.produireComposant().setVisible(false);
                    OperationAdapter operation;
                    operation = (OperationAdapter) instruction.produireComposant();
                    operation.setVisibleEvent(instruction, false);
                }
            }
        }
    }

    @Override
    public void adjustmentValueChanged(AdjustmentEvent e) {
        componentResized(null);
    }

}