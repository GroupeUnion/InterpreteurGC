package xmlstructure;

import interpreteurgraphic.Composant;
import interpreteurgraphic.OperationClass.OperationAdapter;
import java.awt.Color;
import java.awt.Component;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Affectation extends Instruction {

    private Variable source, destination;
    private Variable sauvegarde;
    private final String value, typeid, nameDest, nameSrc;
    private final Variable[] listValues;

    public Affectation(String ident, String ligne, String fichier,
            Variable source, Variable destination, String typeid, String value,
            String nameDest, String nameSrc) {
        super(ident, ligne, fichier);
        this.source = source;
        this.value = value;
        this.typeid = typeid;
        this.listValues = null;
        this.nameSrc = nameSrc;
        this.nameDest = nameDest;
        this.destination = destination;
    }

    public Affectation(String ident, String ligne, String fichier,
            Variable source, Variable destination, String typeid, List<Variable> listValues,
            String nameDest, String nameSrc) {
        super(ident, ligne, fichier);
        this.source = source;
        this.destination = destination;
        this.value = null;
        this.listValues = new Variable[listValues.size()];
        listValues.toArray(this.listValues);
        this.typeid = typeid;
        this.nameDest = nameDest;
        this.nameSrc = nameSrc;
    }

    public String getValue() {
        return value;
    }

    public void affect() {
        Variable variable;
        if ((variable = destination.getVariable(this.nameDest)) != null) {
            destination = variable;
        }
        if (source != null
                && (variable = source.getVariable(this.nameSrc)) != null) {
            source = variable;
        }
        sauvegarderDestination();
        switch (typeid) {
            case "primitif":
                destination.setValeur(value);
                destination.produireComposant().setForeground(Color.red);
                addFleche();
                break;
            case "pointer":
                Pointer pointer = (Pointer) destination;
                if (source == null) {
                    pointer.set(listValues);
                    pointer.produireComposant();
                } else if (source instanceof Array) {
                    pointer.set((Array) source);
                    addFleche();
                    destination.produireComposant().setForeground(Color.red);
                } else if (source instanceof Pointer) {
                    pointer.set(((Pointer) source).dereference());
                    addFleche();
                    destination.produireComposant().setForeground(Color.red);
                } else {
                    pointer.set(source);
                    addFleche();
                    destination.produireComposant().setForeground(Color.red);
                }
                break;
            case "array":
                Array array = (Array) destination;
                if (source == null) {
                    array.set(listValues);
                } else {
                    try {
                        array.setValeur((Array) source.copie());
                    } catch (IOException | ClassNotFoundException ex) {
                        Logger.getLogger(Affectation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                destination.produireComposant().setForeground(Color.red);
                break;
        }
    }

    public void desaffect() {
        switch (typeid) {
            case "primitif":
                destination.setValeur(sauvegarde.getValeur().toString());
                break;
            case "pointer":
                Pointer pointer = (Pointer) destination;
                Composant composant = (Composant) destination.produireComposant();
                pointer.set((Pointer) sauvegarde);
                if (source != null && composant.getComponentCount() != 0) {
                    ((OperationAdapter) composant.getComponent(0)).removeReferer(destination.produireComposant());
                }
                pointer.produireComposant().setVisible(sauvegarde.produireComposant().isVisible());
                break;
            case "array":
                Array array = (Array) destination;
                array.setValeur((Array) sauvegarde);
                break;
        }
        destination.produireComposant().setForeground(Color.WHITE);
        sauvegarde = null;
    }

    private void addFleche() {
        if (source != null) {
            switch (typeid) {
                case "pointer":
                    Composant composant = (Composant) destination.produireComposant();
                    if (composant.getComponentCount() != 0) {
                        ((OperationAdapter) composant.getComponent(0)).addReferer(source.produireComposant());
                    }
                    break;
                case "primitif":
                    ((OperationAdapter) destination.produireComposant()).setToReferer(source.produireComposant());
                    break;
            }
        }
    }

    public void removeFlecheTemporaire() {
        if (source != null && "primitif".equals(typeid)) {
            ((OperationAdapter) destination.produireComposant()).removeReferer(source.produireComposant());
        }
        destination.produireComposant().setForeground(Color.WHITE);
        //sauvegarde = null;
    }

    private void sauvegarderDestination() {
        if (sauvegarde == null) {
            try {

                sauvegarde = destination.copie();
            } catch (IOException | ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Component produireComposant() {
        return destination.produireComposant();
    }

}
