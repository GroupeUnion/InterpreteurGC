package xmlstructure;

import interpreteurgraphic.Composant;
import interpreteurgraphic.Label;
import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;

public class Array extends Variable implements Serializable {

    protected Variable listCases[];
    private boolean isPointer;
    private int nbElement;
    private Composant composant;

    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, int count) {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        if (!this.isPointer) {
            this.nbElement = count;
            listCases = new Variable[nbElement];
            String typeCase = type.replaceAll("\\[\\]", "").trim();
            for (int i = 0; i < listCases.length; i++) {
                listCases[i] = new Variable(this.ident, typeCase, "[" + i + "]", "", this.ligne, this.fichier);
            }
        }
    }

    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, List<Variable> listVariable) {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        this.nbElement = listVariable.size();
        this.listCases = new Variable[listVariable.size()];
        listVariable.toArray(this.listCases);
    }

    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, Structure modele, int count) throws IOException, ClassNotFoundException {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        this.nbElement = count;
        listCases = new Variable[nbElement];
        for (int i = 0; i < listCases.length; i++) {
            listCases[i] = modele.copie();
            listCases[i].setNom("[" + i + "]");
        }
    }

    @Override
    public String getType() {
        return type.replaceAll("\\(.*?\\)", "*").trim(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Variable getVariable(String name, String parent) {
        if (isPointer && listCases == null) {
            return null;
        }
        for (Variable variable : listCases) {
            String newParentName = variable.getNomComplet(parent);
            if (newParentName.equals(name)) {
                return variable;
            } else if ((variable = variable.getVariable(name, newParentName)) != null) {
                return variable;
            }
        }
        return null;
    }

    @Override
    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public void setValeur(String valeur) {
        if (listCases != null) {
            listCases[0].setValeur(valeur);
        }
    }

    public void setValeur(Array copy) {
        listCases = copy.listCases;
        reconstruireComposant();
    }

    /*clonage du tableau*/
    @Override
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();
        return copied;
    }

    public boolean isPointer() {
        return isPointer;
    }

    public void set(Variable[] listVariable) {
        if (listCases == null) {
            listCases = listVariable;
        } else {
            System.arraycopy(listVariable, 0, listCases, 0, listVariable.length);
            this.reconstruireComposant();
        }
    }

    /*pointeur identique*/
    public void set(Variable variable) {
        if (variable instanceof Array) {
            listCases = ((Array) variable).listCases;
        } else if (variable instanceof Structure) {
            if (listCases == null) {
                listCases = new Variable[1];
            }
            Structure indirection = new Structure(null, variable.getType(), (isPointer) ? "" : "[0]", null, null);
            Variable[] tabMembre = ((Structure) variable).getValeurs();
            for (Variable membre : tabMembre) {
                indirection.addMembre(membre);
            }
            listCases[0] = indirection;
        } else {
            if (listCases == null) {
                listCases = new Variable[1];
            }
            listCases[0] = new Variable(null, variable.getType(), (isPointer) ? "" : "[0]", "", null, null);
            listCases[0].setValeur(variable.getValeur());
        }
    }

    @Override
    public String toString() {
        if (isPointer && listCases == null) {
            return super.toString() + " NULL";
        }
        String e = " [ " + listCases[0].toString();
        for (int i = 1; i < listCases.length && i < 15; i++) {
            e += " , " + listCases[i].toString();
        }
        return super.toString() + e + " ]"; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Component produireComposant() {
        if (composant == null) {
            composant = new Composant(getType() + " " + nom);
            if (listCases != null) {
                for (int i = 0; i < listCases.length; i++) {
                    Variable variable = listCases[i];
                    Component component = variable.produireComposant();
                    if (component instanceof Label) {
                        ((Label) component).setHaveMargin(false);
                    }
                    component.setName(variable.getNom());
                    component.setVisible(true);
                    composant.add(component);
                }
            }
            composant.setVisible(false);
        }
        return composant;
    }

    public void reconstruireComposant() {
        if (composant != null) {
            composant.removeAll();
            if (listCases != null) {
                for (int i = 0; i < listCases.length; i++) {
                    Variable variable = listCases[i];
                    Component component = variable.produireComposant();
                    if (component instanceof Label) {
                        ((Label) component).setHaveMargin(false);
                    }
                    component.setName("[" + i + "]");
                    composant.add(component);
                }
            }
        }
    }

}
