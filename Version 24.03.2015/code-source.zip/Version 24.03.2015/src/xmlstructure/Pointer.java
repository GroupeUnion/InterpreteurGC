package xmlstructure;

import interpreteurgraphic.Composant;
import interpreteurgraphic.Label;
import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Pointer extends Variable implements Serializable {

    private Array array;
    private Composant composant;

    public Pointer(Array array) {
        super(String.valueOf(array.getIdent()), array.getType(), array.getNom(), "", String.valueOf(array.getLigne()), array.getFichier());
        this.type = array.type;
        this.nom = array.nom;
        this.array = array;
    }

    /*Initialisation d'un tableau de structure*/
    public void set(Array array) {
        if (this.array != null) {
            this.array.reconstruireComposant();
        }
        if (composant != null) {
            composant.removeAll();
        }
        this.array = array;
    }

    public void set(Variable variable) {
        if (this.array != null) {
            this.array.reconstruireComposant();
        }
        if (composant != null) {
            composant.removeAll();
        }
        this.array = new Array(ident, type, nom, true, ligne, fichier, 0);
        this.array.set(variable);
    }

    public void set(Pointer p) {
        if (this.array != null) {
            this.array.reconstruireComposant();
        }
        composant.removeAll();
        this.array = p.array;
    }

    @Override
    public Variable getVariable(String name) {
        if (this.nom.equals(name)) {
            return this;
        }
        return array.getVariable(name, this.nom);
    }

    @Override
    public Variable getVariable(String name, String parent) {
        return array.getVariable(name, parent);
    }

    @Override
    public String getType() {
        return type.replaceAll("\\(.*?\\)", "*").trim();
    }

    @Override
    public StringBuilder getValeur() {
        return array.getValeur();
    }

    @Override
    public String getNomComplet(String parent) {
        return array.getNomComplet(parent);
    }

    @Override
    public void setValeur(String valeur) {
        this.array.setValeur(valeur);
    }

    @Override
    public void setValeur(StringBuilder valeur) {
        this.array.setValeur(valeur);
    }

    public void set(Variable[] listVariable) {
        if (this.array != null) {
            this.array.reconstruireComposant();
        }
        composant.removeAll();
        this.array = new Array(ident, type, nom, true, ligne, fichier, 0);
        this.array.set(listVariable);
    }

    public Array dereference() {
        return this.array;
    }

    @Override
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();
        return copied;
    }

    @Override
    public String toString() {
        return array.getType() + " " + array.getNom() + " " + this.array.getValeur();
    }

    @Override
    public Component produireComposant() {
        if (composant == null) {
            composant = new Composant(getType() + " " + nom);
            composant.setVisible(false);
        }
        if (array.listCases != null) {
            for (int i = 0; i < array.listCases.length; i++) {
                Variable variable = array.listCases[i];
                Component component = variable.produireComposant();
                if (component instanceof Label) {
                    ((Label) component).setHaveMargin(false);
                }
                component.setName("[" + i + "]");
                composant.add(component);
                component.setVisible(true);
            }            
        }
        return composant;
    }
}
