#include "autre.h"
#include <string.h>
int j = 0;
char mot[20];

void function()
{
	int h = 0;	
}