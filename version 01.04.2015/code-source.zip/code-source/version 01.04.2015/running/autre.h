#ifdef H_AUTRE
#define H_AUTRE
#include <string.h>
void function();
extern char mot[20];
#endif