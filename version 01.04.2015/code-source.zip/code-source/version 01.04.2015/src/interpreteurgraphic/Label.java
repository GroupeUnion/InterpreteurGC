package interpreteurgraphic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import interpreteurgraphic.OperationClass.OperationAdapter;
import interpreteurgraphic.OperationClass.OperationListener;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.EventListenerList;
import xmlstructure.Instruction;

/**
 *
 * @author mahamat
 */
public class Label extends JLabel implements OperationAdapter {

    private final EventListenerList listeners = new EventListenerList();
    private final StringBuilder valeur;
    private boolean haveMargin;
    private Color color;
    private Dimension titleSize;
    private final Font pFont;
    private boolean isDeplacable;

    public Label(StringBuilder valeur, String text) {
        super(getValeur(valeur.toString()));
        this.pFont = new Font("times new roman", Font.PLAIN, 12);
        this.valeur = valeur;
        this.haveMargin = true;
        this.color = Color.getHSBColor((float) (136 / 256.0), (float) (240 / 256.0), (float) (256 / 256.0));
        this.setName(text != null ? text : "");
        this.setForeground(Color.WHITE);
        this.isDeplacable = true;
        if (valeur.toString().matches("(.*)@[0-9]*")) {
            JLabel ascii = new JLabel("[" + valeur.toString().replaceAll("(.*)@", "") + "]");
            ascii.setSize(titleSize.width, titleSize.height);
            ascii.setLocation(titleSize.width + 5, 9);
            ascii.setForeground(Color.WHITE);
            this.add(ascii);
        }
    }

    private static String getValeur(String valeur) {
        if ("NOINIT".equals(valeur)) {
            return "";
        } else if (valeur.matches("(.*)@[0-9]*")) {
            return valeur.replaceAll("@[0-9]*", "");
        }

        return valeur;
    }

    @Override
    public void setForeground(Color fg) {
        super.setForeground(fg); //To change body of generated methods, choose Tools | Templates.
        if (Color.WHITE == fg) {
            this.color = Color.getHSBColor((float) (136 / 256.0), (float) (240 / 256.0), (float) (256 / 256.0));
            if (this.getName() != null) {
                setMargin(0, 40, 0, 0);
            }
        } else if (this.getName() != null) {
            this.color = fg;
            setMargin(0, 40, 0, 0);
        }
        if (this.getComponentCount() != 0) {
            this.getComponent(0).setForeground(fg);
        }
    }

    @Override
    public void setName(String name) {
        super.setName(name); //To change body of generated methods, choose Tools | Templates.
        if (!"".equals(getName())) {
            FontMetrics fontMetrics = this.getFontMetrics(pFont);
            if(this.getComponentCount()!= 0)
                name +=((JLabel)this.getComponent(0)).getText();
            titleSize = new Dimension(fontMetrics.stringWidth(name) + 10, 30);
        }
        this.setMargin(0, 40, 0, 0);
    }

    @Override
    public OperationClass.enumFigure getTypeFigure() {
        return OperationClass.enumFigure.label;
    }

    @Override
    public Rectangle getBounds() {
        Rectangle coords = SwingUtilities.convertRectangle(this, new Rectangle(this.haveMargin ? 40 : 0, 5, 0, 0), Fenetre.flechePanel);
        coords.setSize(this.getWidth() - (this.haveMargin ? 40 : 0), this.getHeight() - 10);
        return coords; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); //To change body of generated methods, choose Tools | Templates.
        setText(getValeur(valeur.toString()));
        if (this.getComponentCount() != 0) {
            ((JLabel) this.getComponent(0)).setText("[" + valeur.toString().replaceAll("(.*)@", "") + "]");
        }
    }

    @Override
    public void setMargin(int top, int left, int bottom, int right) {
        Border colorBorder = BorderFactory.createMatteBorder(1, 1, 1, 1, color);
        Border textBorder = BorderFactory.createTitledBorder(colorBorder, this.getName(), TitledBorder.CENTER, TitledBorder.DEFAULT_POSITION, pFont, color);
        Border margin = BorderFactory.createEmptyBorder(top, (titleSize != null) ? titleSize.width : left, bottom, right);
        Border combinaisonBorder = BorderFactory.createCompoundBorder(textBorder, margin);
        if (haveMargin) {
            Border margin2 = BorderFactory.createEmptyBorder(0, 40, 0, 0);
            Border combinaisonBorder2 = BorderFactory.createCompoundBorder(margin2, combinaisonBorder);
            this.setBorder(combinaisonBorder2);
        } else {
            this.setBorder(combinaisonBorder);
        }
        if (this.getComponentCount() != 0) {
            this.getComponent(0).setLocation(haveMargin ? 45 : 5, 9);
        }
    }

    @Override
    public void addReferer(Component toReferer) {
        Fenetre.flechePanel.addFleche(toReferer, this);
    }

    @Override
    public void setToReferer(Component toReferer) {
        Fenetre.flechePanel.removeFlecheTo(this);
        Fenetre.flechePanel.addFleche(toReferer, this);
    }

    @Override
    public void removeReferer(Component toReferer) {
        Fenetre.flechePanel.removeFleche(this, toReferer);
    }

    @Override
    public void setHaveMargin(boolean haveMargin) {
        this.haveMargin = haveMargin;
    }

    @Override
    public void addOperationListener(OperationListener operation) {
        listeners.add(OperationListener.class, operation);
    }

    @Override
    public void setVisibleEvent(Instruction source, boolean isVisible) {
        if (listeners.getListenerCount() != 0) {
            OperationListener operation[] = listeners.getListeners(OperationListener.class);
            for (OperationListener op : operation) {
                op.componentEvent(isVisible);
            }
        }
        if ("void @return".equals(getName())) {
            this.setVisible(false);
        }
    }

    @Override
    public void setVisible(boolean aFlag) {
        if (!"EOF".equals(this.valeur.toString()) || !aFlag) {
            super.setVisible(aFlag); //To change body of generated methods, choose Tools | Templates.
        }
    }

    @Override
    public void setDeplacable(boolean isDeplacable) {
        this.isDeplacable = isDeplacable;
    }

}
