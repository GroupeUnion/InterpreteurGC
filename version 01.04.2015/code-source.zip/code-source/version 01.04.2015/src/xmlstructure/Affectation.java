package xmlstructure;

import interpreteurgraphic.OperationClass.OperationAdapter;
import java.awt.Color;
import java.awt.Component;
import java.io.IOException;
import java.util.List;
import xmlstructure.Variable.MemorySet;

/**
 *
 * @author mahamat
 */
public class Affectation extends Instruction {

    private Variable source, destination;
    private Variable sauvegarde;
    private final String value, typeid, nameDest, nameSrc;
    private final Variable[] listValues;

    public Affectation(String ident, String ligne, String fichier,
            Variable source, Variable destination, String typeid, String value,
            String nameDest, String nameSrc) {
        super(ident, ligne, fichier);
        this.source = source;
        this.value = value;
        this.typeid = typeid;
        this.listValues = null;
        this.nameSrc = nameSrc;
        this.nameDest = nameDest;
        this.destination = destination;
    }

    public Affectation(String ident, String ligne, String fichier,
            Variable source, Variable destination, String typeid, List<Variable> listValues,
            String nameDest, String nameSrc) {
        super(ident, ligne, fichier);
        this.source = source;
        this.destination = destination;
        this.value = null;
        if (!listValues.isEmpty()) {
            this.listValues = new Variable[listValues.size()];
            listValues.toArray(this.listValues);
        } else {
            this.listValues = null;
        }
        this.typeid = typeid;
        this.nameDest = nameDest;
        this.nameSrc = nameSrc;
    }

    public String getValue() {
        return value;
    }

    public void affect() {
        try {
            Variable variableDest = destination;
            Variable variableSource = null;
            destination = destination.getVariable(this.nameDest);
            if (source != null
                    && (source = source.getVariable(this.nameSrc)) != null) {
                variableSource = source;
            }
            if (sauvegarde == null) {
                sauvegarde = destination.copie();
            }
            switch (enumType.getTypeOf(typeid)) {
                case primitif:
                    destination.setValeur(value);
                    if (source != null) {
                        ((OperationAdapter) destination.produireComposant()).setToReferer(source.produireComposant());
                    }
                    break;
                case array:
                case pointer:
                    if (destination instanceof Pointer || destination instanceof Array) {
                        MemorySet pointer = (MemorySet) destination;
                        if (source == null) {
                            pointer.set(listValues);
                            destination.produireComposant();
                        } else if (source instanceof Array) {
                            pointer.set((Array) source);
                        } else if (source instanceof Pointer) {
                            pointer.set(((Pointer) source));
                        } else {
                            pointer.set(source);
                        }
                    } else {
                        if (source != null && source instanceof Pointer) {
                            destination.setValeur(((Pointer) source).getValeur().toString());
                        } else if (destination instanceof Variable && listValues != null) {
                            destination.setValeur(listValues[0].getValeur().toString());
                        }
                    }
                    break;
                case dessalloc:
                    if (destination instanceof Pointer || destination instanceof Array) {
                        MemorySet pointer = (MemorySet) destination;
                        if (source == null) {
                            pointer.set((Variable[]) null);
                        }
                    }
                    break;
            }
            destination = variableDest;
            source = variableSource;
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void desaffect() {
        switch (enumType.getTypeOf(typeid)) {
            case primitif:
                destination.setValeur(sauvegarde.getValeur().toString());
                destination.produireComposant().setVisible(sauvegarde.produireComposant().isVisible());
                destination.produireComposant().setForeground(sauvegarde.produireComposant().getForeground());
                break;
            case dessalloc:
            case array:
            case pointer:
                if (destination instanceof Pointer || destination instanceof Array) {
                    MemorySet pointer = (MemorySet) destination;
                    if (listValues != null) {
                        pointer.set((Variable[]) null);
                    }
                    if (sauvegarde instanceof Pointer) {
                        pointer.set((Pointer) sauvegarde);
                    } else {
                        pointer.set((Array) sauvegarde);
                    }
                } else if (destination instanceof Variable) {
                    destination.setValeur(sauvegarde.getValeur());
                }
                destination.produireComposant().setForeground(sauvegarde.produireComposant().getForeground());
                destination.produireComposant().setVisible(sauvegarde.produireComposant().isVisible());
                break;
        }
        sauvegarde = null;
    }

    public void removeFlecheTemporaire() {
        if (source != null) {
            Variable variableDest = destination.getVariable(this.nameDest);
            Variable variableSource = source.getVariable(this.nameSrc);
            if ("primitif".equals(typeid)) {
                ((OperationAdapter) variableDest.produireComposant()).removeReferer(variableSource.produireComposant());
            }
            variableSource.produireComposant().setForeground(Color.WHITE);
        }
    }

    @Override
    public Component produireComposant() {
        Variable variableDest = destination.getVariable(this.nameDest);
        return variableDest.produireComposant();
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.affectation;
    }

}
