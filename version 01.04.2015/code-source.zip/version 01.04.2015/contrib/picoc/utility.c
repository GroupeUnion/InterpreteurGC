#include "utility.h"
int balisage_fonction = 0;
int identifiant = 1;
char tabulation[250] = { 0 };
struct Ident RefsMain;

void write_in_xmlfile(const char * format, ...)
{
	if (!balisage_fonction)
	{
		va_list args;
		va_start(args, format);
		if (file_xml_ptr == NULL)
			vprintf(format, args);
		else
			vfprintf(file_xml_ptr, format, args);
		va_end(args);
	}
}

char * get_filename(char * path)
{
	char *pfile;
	pfile = path + strlen(path);
	for (; pfile > path; pfile--)
	{
		if ((*pfile == '\\') || (*pfile == '/'))
		{
			pfile++;
			break;
		}
	}
	return pfile;
}

int isInitialised(struct Value * value_)
{
	switch (value_->Typ->Base)
	{
	case TypeInt:				return value_->Val->Integer != (int)MAX_INT; 
	case TypeShort:				return value_->Val->ShortInteger != (short)MAX_INT; 
	case TypeChar:				return value_->Val->Character != (unsigned char)MAX_INT; 
	case TypeLong:				return value_->Val->LongInteger != (long)MAX_INT;
	case TypeUnsignedShort:		return value_->Val->UnsignedShortInteger != (unsigned short)MAX_INT; 
	case TypeUnsignedInt:		return value_->Val->UnsignedInteger != (unsigned int)MAX_INT;
	case TypeUnsignedLong:		return value_->Val->UnsignedLongInteger != (unsigned long)MAX_INT;
	case TypeDouble:			
	case TypeFP:				return value_->Val->FP != (double)MAX_INT;
	default:
		;
	}
	return 1;
}

void write_type_name(struct ValueType * value_)
{
	if (value_->FromType != 0 && value_->Base != TypeStruct)
		write_type_name(value_->FromType);
	switch (value_->Base)
	{
	case TypeVoid:				write_in_xmlfile("void"); break;
	case TypeInt:				write_in_xmlfile("int"); break;
	case TypeShort:				write_in_xmlfile("short"); break;
	case TypeChar:				write_in_xmlfile("char"); break;
	case TypeLong:				write_in_xmlfile("long"); break;
	case TypeUnsignedShort:		write_in_xmlfile("unsigned short"); break;
	case TypeUnsignedInt:		write_in_xmlfile("unsigned int"); break;
	case TypeUnsignedLong:		write_in_xmlfile("unsigned long"); break;
	case TypeDouble:			write_in_xmlfile("double"); break;
	case TypeFP:				write_in_xmlfile("float"); break;
	case TypeFunction:			write_in_xmlfile("function"); break;
	case TypeMacro:				write_in_xmlfile("macro"); break;
	case TypePointer:			write_in_xmlfile("*", value_->ArraySize); break;
	case TypeArray:				write_in_xmlfile("[]", value_->ArraySize); break;
	case TypeStruct:			write_in_xmlfile("struct %s", value_->Identifier); break;
	case TypeUnion:				write_in_xmlfile("union"); break;
	case TypeEnum:				write_in_xmlfile("enum"); break;
	case Type_Type:				write_in_xmlfile("type"); break;
	default:					write_in_xmlfile("unknown"); break;
	}
}

void write_array_value(struct ValueType* Typ, struct Value * value_ptr, int index)
{
	struct ValueType* saveType = value_ptr->Typ;
	union AnyValue * saveValue = value_ptr->Val;
	value_ptr->Typ = Typ;
	value_ptr->Val = (union AnyValue *)(&value_ptr->Val->ArrayMem[0] + TypeSize(Typ, 0, TRUE) * index);
	write_object_value(value_ptr);
	value_ptr->Val = saveValue;
	value_ptr->Typ = saveType;
}

void write_pointer_value(struct ValueType* Typ, struct Value * value_ptr, int index)
{
	struct ValueType* saveType = value_ptr->Typ;
	union AnyValue * saveValue = value_ptr->Val;
	value_ptr->Typ = Typ;
	value_ptr->Val = (union AnyValue*)((char *)value_ptr->Val->Pointer + TypeSize(Typ, 0, TRUE) * index);
	write_object_value(value_ptr);
	value_ptr->Val = saveValue;
	value_ptr->Typ = saveType;
}



void write_object_value(struct Value * value_ptr)
{
	int index;
	if (!isInitialised(value_ptr))
	{
		write_in_xmlfile("NOINIT");
		return;
	}
	switch (value_ptr->Typ->Base)
	{
	case TypeVoid:				write_in_xmlfile("EOF"); break;
	case TypeInt:				write_in_xmlfile("%d", value_ptr->Val->Integer); break;
	case TypeShort:				write_in_xmlfile("%hd", value_ptr->Val->ShortInteger); break;
	case TypeChar:
	{
		switch (value_ptr->Val->Character)
		{
		case '\0':
			write_in_xmlfile("\\0");
			break;
		case '\n':
			write_in_xmlfile("\\n");
			break;
		case '\t':
			write_in_xmlfile("\\t");
			break;
		case '\r':
			write_in_xmlfile("\\r");
			break;
		case '<':
			write_in_xmlfile("&lt");
			break;			
		default:
			if (value_ptr->Val->Character < 32)
				write_in_xmlfile("\\x%d", value_ptr->Val->Character);
			else
				write_in_xmlfile("%c", value_ptr->Val->Character); 
			break;
		}
		write_in_xmlfile("\" ascii=\"%d", value_ptr->Val->Character);
		break;
	}
	case TypeLong:				write_in_xmlfile("%ld", value_ptr->Val->LongInteger); break;
	case TypeUnsignedShort:		write_in_xmlfile("%hu", value_ptr->Val->UnsignedShortInteger); break;
	case TypeUnsignedInt:		write_in_xmlfile("%u", value_ptr->Val->UnsignedInteger); break;
	case TypeUnsignedLong:		write_in_xmlfile("%lu", value_ptr->Val->UnsignedLongInteger); break;
	case TypeDouble:			write_in_xmlfile("%f", value_ptr->Val->FP); break;
	case TypeFP:				write_in_xmlfile("%f", value_ptr->Val->FP); break;
	case TypeFunction:			write_in_xmlfile(value_ptr->Val->Identifier); break;
	case TypeMacro:				write_in_xmlfile(value_ptr->Val->Identifier); break;
	case TypePointer:
	{
		if (value_ptr->Val == NULL || value_ptr->Val->Pointer == NULL)
		{
			write_in_xmlfile("");
			break;
		}
		else if (value_ptr->Typ->FromType->Base == TypeVoid && value_ptr->TypContrib)
		{
			value_ptr->Typ->FromType = value_ptr->TypContrib->FromType;
		}
		strcat(tabulation, "   ");
		write_in_xmlfile("\n");
		for (index = 0; index < value_ptr->Typ->ArraySize; index++)
		{
			write_in_xmlfile("%s<var type=\"", tabulation);
			write_type_name(value_ptr->Typ->FromType);
			write_in_xmlfile("\" typeid=\"%s\" name=\"[%d]\"", value_ptr->Typ->FromType->TypeId, index);
			switch (value_ptr->Typ->FromType->Base)
			{
			case TypeArray:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_pointer_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			case TypeStruct:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_pointer_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			case TypeUnion:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_pointer_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			case TypePointer:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_pointer_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			default:
				write_in_xmlfile(" value=\"");
				write_pointer_value(value_ptr->Typ->FromType, value_ptr, index);
				write_in_xmlfile("\"></var>\n");
				break;
			}
		}
		tabulation[strlen(tabulation) - 3] = '\0';
	}
	break;
	case TypeArray:
	{
		strcat(tabulation, "   ");
		write_in_xmlfile("\n");
		for (index = 0; index < value_ptr->Typ->ArraySize; index++)
		{
			write_in_xmlfile("%s<var type=\"", tabulation);
			write_type_name(value_ptr->Typ->FromType);
			write_in_xmlfile("\" typeid=\"%s\" name=\"[%d]\"", value_ptr->Typ->FromType->TypeId, index);
			switch (value_ptr->Typ->FromType->Base)
			{
			case TypeArray:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_array_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			case TypeStruct:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_array_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			case TypeUnion:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_array_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			case TypePointer:
				write_in_xmlfile(">\n");
				strcat(tabulation, "   ");
				write_array_value(value_ptr->Typ->FromType, value_ptr, index);
				tabulation[strlen(tabulation) - 3] = '\0';
				write_in_xmlfile("%s</var>\n", tabulation);
				break;
			default:
				write_in_xmlfile(" value=\"");
				write_array_value(value_ptr->Typ->FromType, value_ptr, index);
				write_in_xmlfile("\"></var>\n");
				break;
			}
		}
		tabulation[strlen(tabulation) - 3] = '\0';
		break;
	}
	case TypeStruct:			write_in_xmlfile("\n"); strcat(tabulation, "   ");  write_structure_value(value_ptr->Typ->LMembres, (void*)value_ptr->Val); tabulation[strlen(tabulation) - 3] = '\0'; break;
	case TypeUnion:				write_in_xmlfile("%s:union", value_ptr->Val->Identifier); break;
	case TypeEnum:				write_in_xmlfile("%s:enum", value_ptr->Val->Identifier); break;
	case Type_Type:				write_in_xmlfile(":type"); break;
	default:					write_in_xmlfile("unknown"); break;
	}
}


struct Members *  add_member_name(struct Members ** member, char * ident, struct Value * MemberValue)
{
	if (*member == NULL)
	{
		*member = malloc(sizeof(struct Members));
		(*member)->Ident = ident;
		(*member)->MemberValue = MemberValue;
		(*member)->Next = NULL;
		(*member)->NextMemberOffset = 0;
		return *member;
	}
	else
	{
		return add_member_name(&((*member)->Next), ident, MemberValue);
	}

}

void init_type_id(struct ValueType *Typ)
{
	switch (Typ->Base)
	{
	case TypePointer: strcpy(Typ->TypeId, "pointer"); break;
	case TypeArray:	strcpy(Typ->TypeId, "array"); break;
	case TypeStruct: strcpy(Typ->TypeId, "struct"); break;
	default:
		strcpy(Typ->TypeId, "primitif");
		break;
	}
}

void write_structure_member(struct Members * membre)
{
	struct Members * current;
	strcat(tabulation, "   ");
	for (current = membre; current != NULL; current = current->Next)
		write_variable(0, 0, NULL, current->MemberValue->Typ, current->Ident, NULL);
	tabulation[strlen(tabulation) - 3] = '\0';
}


void write_structure_value(struct Members * membre, char * adresse)
{
	struct Members * current;
	union AnyValue *FromValue;

	strcat(tabulation, "   ");
	for (current = membre; current != NULL; current = current->Next)
	{
		FromValue = current->MemberValue->Val;
		current->MemberValue->Val = (void *)(adresse + current->NextMemberOffset);
		write_variable(0, 0, NULL, current->MemberValue->Typ, current->Ident, current->MemberValue);
		current->MemberValue->Val = FromValue;
	}
	tabulation[strlen(tabulation) - 3] = '\0';
}

void write_variable(int Id, int Line, char *File, struct ValueType *Typ, char *Name, struct Value * Valeur)
{
	if (Id != 0)
	{
		write_in_xmlfile("%s<var id=\"%d\" line=\"%d\" file=\"%s\" type=\"",
			tabulation, Id, Line, get_filename(File));
	}
	else
	{
		write_in_xmlfile("%s<var type=\"", tabulation);
	}
	write_type_name(Typ);
	write_in_xmlfile("\" typeid=\"%s\" name=\"%s\"", Typ->TypeId, Name);
	if (Valeur != NULL && Valeur->RefsourceContrib != NULL)
		write_in_xmlfile(" id_src=\"%d\" nsrc=\"%s\"", Valeur->RefsourceContrib->OrderNum, Valeur->RefsourceContrib->Name);
	if (Valeur != NULL && ((Typ->Base == TypePointer && Valeur->RefsourceContrib == NULL) || Typ->Base != TypePointer))
	{
		if (strcmp(Typ->TypeId, "primitif") != 0)
		{
			if (Typ->Base != TypeStruct)
				write_in_xmlfile(" count=\"%d\"", Typ->SizeArrayOf);
			write_in_xmlfile(">");
			write_object_value(Valeur);
			write_in_xmlfile(tabulation);
		}
		else
		{
			write_in_xmlfile(" value=\"");
			write_object_value(Valeur);
			write_in_xmlfile("\">");
		}
	}
	else
	{
		if (Typ->Base != TypeStruct && strcmp(Typ->TypeId, "primitif") != 0 && Typ->Base != TypePointer)
			write_in_xmlfile(" count=\"%d\"", Typ->SizeArrayOf);
		write_in_xmlfile(">");
	}

	write_in_xmlfile("</var>\n");
}

void write_return(int Id, int Line, char *File, struct ValueType *Typ, struct Value * Valeur)
{
	write_in_xmlfile("%s<return id=\"%d\" line=\"%d\" file=\"%s\" type=\"", tabulation, Id, Line, File);
	write_type_name(Typ);
	write_in_xmlfile("\" typeid=\"%s\" name=\"@return\"", Typ->TypeId);
	if (Valeur != NULL && Valeur->RefdestContrib != NULL)
		write_in_xmlfile(" id_src=\"%d\" nsrc=\"%s\"", Valeur->RefdestContrib->OrderNum, Valeur->RefdestContrib->Name);
	if (Valeur != NULL)
	{
		if (strcmp(Typ->TypeId, "primitif") != 0)
		{
			Typ->SizeArrayOf = Typ->SizeArrayOf > Typ->ArraySize ? Typ->SizeArrayOf : Typ->ArraySize;
			if (Typ->Base != TypeStruct)
				write_in_xmlfile(" count=\"%d\"", Typ->SizeArrayOf);
			write_in_xmlfile(">");
			write_object_value(Valeur);
			write_in_xmlfile(tabulation);
		}
		else
		{
			write_in_xmlfile(" value=\"");
			write_object_value(Valeur);
			write_in_xmlfile("\">");

		}
	}
	write_in_xmlfile("</return>\n");
}

void write_affectation(int Id, int Line, char *File, struct ValueType * Typ, struct Value * Valeur)
{
	write_in_xmlfile("%s<affect id=\"%d\" line=\"%d\" file=\"%s\"", tabulation, Id, Line, File);
	write_in_xmlfile(" typeid=\"%s\"", Typ->TypeId);
	if (Valeur->RefsourceContrib != NULL)
		write_in_xmlfile(" id_src=\"%d\" nsrc=\"%s\"", Valeur->RefsourceContrib->OrderNum, Valeur->RefsourceContrib->Name);
	write_in_xmlfile(" id_dest=\"%d\" ndest=\"%s\"", Valeur->RefdestContrib->OrderNum, Valeur->RefdestContrib->Name);
	if (Valeur != NULL && ((Typ->Base == TypePointer && Valeur->RefsourceContrib == NULL) || Typ->Base != TypePointer))
	{
		if (strcmp(Typ->TypeId, "primitif") == 0)
		{
			write_in_xmlfile(" value=\"");
			write_object_value(Valeur);
			write_in_xmlfile("\">");
		}
		else
		{
			if (Typ->Base != TypeStruct)
			{
				Typ->SizeArrayOf = Typ->SizeArrayOf > Typ->ArraySize ? Typ->SizeArrayOf : Typ->ArraySize;
				write_in_xmlfile(" count=\"%d\"", Typ->SizeArrayOf);
			}
			write_in_xmlfile(">");
			write_object_value(Valeur);
			write_in_xmlfile(tabulation);
		}
	}
	else
		write_in_xmlfile(">");
	write_in_xmlfile("</affect>\n");
}

void write_paramater(int Id, int Line, char *File, struct ValueType * Typ, char *Name, struct Value * Valeur)
{
	write_in_xmlfile("%s<param id=\"%d\" line=\"%d\" file=\"%s\" type=\"", tabulation, Id, Line, get_filename(File));
	write_type_name(Typ);
	write_in_xmlfile("\" typeid=\"%s\" name=\"%s\"", Typ->TypeId, Name);
	if (Valeur != NULL && Valeur->RefdestContrib != NULL)
		write_in_xmlfile(" id_src=\"%d\" nsrc=\"%s\"", Valeur->RefdestContrib->OrderNum, Valeur->RefdestContrib->Name);
	if (Valeur != NULL && (((Typ->Base == TypePointer || Typ->Base == TypeArray) && Valeur->RefdestContrib == NULL) ||
		(Typ->Base != TypePointer && Typ->Base != TypeArray)))
	{
		if (strcmp(Typ->TypeId, "primitif") != 0)
		{
			Typ->SizeArrayOf = Typ->SizeArrayOf > Typ->ArraySize ? Typ->SizeArrayOf : Typ->ArraySize;
			if (Typ->Base != TypeStruct)
				write_in_xmlfile(" count=\"%d\"", Typ->SizeArrayOf);
			write_in_xmlfile(">");
			write_object_value(Valeur);
			write_in_xmlfile(tabulation);
		}
		else
		{
			write_in_xmlfile(" value=\"");
			write_object_value(Valeur);
			write_in_xmlfile("\">");
		}
	}
	else
	{
		/*if (Typ->Base != TypeStruct && strcmp(Typ->TypeId, "primitif") != 0)
			write_in_xmlfile(" count=\"%d\"", Typ->SizeArrayOf);*/
		write_in_xmlfile(">");
	}
	write_in_xmlfile("</param>\n");
}

char *_strdup_(const char *s)
{
	char *d = malloc(strlen(s) + 1);
	if (d == NULL) return NULL;
	strcpy(d, s);
	return d;
}


char *strconcat(char **s1, char *s2)
{
	size_t old_size;
	char *t;

	old_size = strlen(*s1);

	/* cannot use realloc() on initial const char* */
	t = malloc(old_size + strlen(s2) + 1);
	strcpy(t, *s1);
	strcpy(t + old_size, s2);
	free(*s1);
	*s1 = t;
	return t;
}

int __vscprintf(const char * format, va_list pargs) {
	int retval;
	va_list argcopy;
	va_copy(argcopy, pargs);
	retval = vsnprintf(NULL, 0, format, pargs);
	va_end(argcopy);
	return retval;
}

char * _strcat(char * buffer, char *addition)
{
	return strconcat(&buffer, addition);
}


char * _sprintf(char * format, ...)
{
	va_list args;
	int     len;
	char    *buffer;
	va_start(args, format);

	len = __vscprintf(format, args) + 1;
	buffer = (char*)malloc(len * sizeof(char));
	vsprintf(buffer, format, args);
	return buffer;
}


/*-----------------------------------------------------------------------------------*/

void init_array_value(struct ValueType* Typ, struct Value * value_ptr, int index)
{
	struct ValueType* saveType = value_ptr->Typ;
	value_ptr->Typ = Typ;
	value_ptr->Val = (union AnyValue *)(&value_ptr->Val->ArrayMem[0] + TypeSize(Typ, 0, TRUE) * index);
	init_object_value(value_ptr);
	value_ptr->Val = (union AnyValue *)(&value_ptr->Val->ArrayMem[0] - TypeSize(Typ, 0, TRUE) * index);
	value_ptr->Typ = saveType;
	saveType = NULL;
}

void init_pointer_value(struct ValueType* Typ, struct Value * value_ptr, int index)
{
	struct ValueType* saveType = value_ptr->Typ;
	union AnyValue * saveValue = value_ptr->Val;
	value_ptr->Typ = Typ;
	value_ptr->Val = (union AnyValue*)((char *)value_ptr->Val->Pointer + TypeSize(Typ, 0, TRUE) * index);
	init_object_value(value_ptr);
	value_ptr->Val = saveValue;
	value_ptr->Typ = saveType;
}


void init_object_value(struct Value * value_ptr)
{
	int index;
	switch (value_ptr->Typ->Base)
	{
	case TypeInt:				value_ptr->Val->Integer = MAX_INT; break;
	case TypeShort:				value_ptr->Val->ShortInteger = (short)MAX_INT; break;
	case TypeChar:				value_ptr->Val->Character = (unsigned char)MAX_INT; break;
	case TypeLong:				value_ptr->Val->LongInteger = (long) MAX_INT; break;
	case TypeUnsignedShort:		value_ptr->Val->UnsignedShortInteger = (unsigned short)MAX_INT; break;
	case TypeUnsignedInt:		value_ptr->Val->UnsignedInteger = (unsigned int)MAX_INT; break;
	case TypeUnsignedLong:		value_ptr->Val->UnsignedLongInteger = (unsigned long)MAX_INT; break;
	case TypeDouble:			
	case TypeFP:				value_ptr->Val->FP = (double) MAX_INT; break;
	case TypePointer:
	{
		if (value_ptr->Val == NULL || value_ptr->Val->Pointer == NULL)
			break;
		else if (value_ptr->Typ->FromType->Base == TypeVoid && value_ptr->TypContrib)
			value_ptr->Typ->FromType = value_ptr->TypContrib->FromType;
		for (index = 0; index < value_ptr->Typ->ArraySize; index++)
			init_pointer_value(value_ptr->Typ->FromType, value_ptr, index);
		break;
	}

	case TypeArray:
	{
		for (index = 0; index < value_ptr->Typ->ArraySize; index++)
			init_array_value(value_ptr->Typ->FromType, value_ptr, index);
		break;
	}
	default:  break;
	}
}

