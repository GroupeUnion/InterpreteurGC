/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreteurgraphic;

import interpreteurgraphic.OperationClass.OperationAdapter;
import interpreteurgraphic.OperationClass.OperationListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.EventListenerList;
import xmlstructure.Instruction;

/**
 *
 * @author Asus
 */
public class ArrayFigure extends JPanel implements OperationAdapter {
    
    private final EventListenerList listeners = new EventListenerList();
    private final JPanel listePointer;
    private final Composant array;
    private boolean isDeplacable;
    
    public ArrayFigure() {
        //this.setLayout(new GridLayout(2, 1));
        this.setLayout(new BorderLayout());
        this.setOpaque(false);
        this.listePointer = new JPanel();
        this.array = new Composant("-");
        
        this.listePointer.setBackground(Color.red);
        this.listePointer.setLayout(new FlowLayout(FlowLayout.LEFT));
        this.listePointer.setOpaque(false);
        
        this.add(listePointer, BorderLayout.NORTH);
        this.add(array, BorderLayout.CENTER);
        this.listePointer.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        this.isDeplacable = true;
        this.listePointer.setVisible(true);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); //To change body of generated methods, choose Tools | Templates.
        if (array.getComponentCount() == 0) {
            array.setName("");
            array.setMargin(0, 0, 0, 0);
            array.setVisible(false);
        }
    }
    
    @Override
    public void setForeground(Color fg) {
        super.setForeground(fg); //To change body of generated methods, choose Tools | Templates.
        if (this.listePointer != null) {
            if (array.getComponentCount() != 0) {
                for (Component c : this.listePointer.getComponents()) {
                    c.setForeground(fg);
                }
                array.setForeground(fg);
            }
        }
    }
    
    public void addPointer(Composant c) {
        if (c.isDeplacable() && canMove(c)) {
            listePointer.add(c);
        }
        this.addReferer(c);
    }
    
    private Component getPointer(Component c) {
        if (c instanceof ArrayFigure) {
            return getPointer(((ArrayFigure) c).getPointer());
        }
        return c;
    }
    
    public Component getPointer() {
        return getPointer(this.listePointer.getComponent(0));
    }
    
    public void addCase(Component c) {
        array.add(c);
        if (array.getComponentCount() == 1) {
            for (Component cs : listePointer.getComponents()) {
                this.addReferer(cs);
            }
            array.setName("-");
            array.setMargin(0, 0, 0, 0);
            array.setVisible(true);
        }
    }
    
    public void removeAllCases() {
//        if (this.listePointer.getComponentCount() == 1) {
        array.removeAll();
//        for (Component col : array.getComponents()) {
//            col.setVisible(false);
//        }
//        }
    }
    
    public void removePointer(Component c) {
        this.removeReferer(c);
    }
    
    @Override
    public void addOperationListener(OperationClass.OperationListener operation) {
        listeners.add(OperationClass.OperationListener.class, operation);
    }
    
    @Override
    public void setHaveMargin(boolean haveMargin) {
        array.setHaveMargin(haveMargin);
    }
    
    @Override
    public void setMargin(int top, int left, int bottom, int right) {
        array.setMargin(top, left, bottom, right);
    }
    
    @Override
    public void removeReferer(Component toReferer) {
        if (array.getComponentCount() > 0) {
            Fenetre.flechePanel.removeFleche(getPointer(array.getComponent(0)), toReferer);
        }
    }
    
    @Override
    public void setToReferer(Component toReferer) {
        if (array.getComponentCount() > 0) {
            Fenetre.flechePanel.removeFlecheTo(getPointer(array.getComponent(0)));
            Fenetre.flechePanel.addFleche(toReferer, getPointer(array.getComponent(0)));
            Fenetre.flechePanel.repaint();
        }
    }
    
    @Override
    public void addReferer(Component toReferer) {
        if (array.getComponentCount() > 0) {
            Fenetre.flechePanel.addFleche(toReferer, getPointer(array.getComponent(0)));
            Fenetre.flechePanel.repaint();
        }
    }
    
    @Override
    public OperationClass.enumFigure getTypeFigure() {
        return OperationClass.enumFigure.arrayfigure;
    }
    
    @Override
    public Rectangle getBounds() {
        return array.getBounds();
    }
    
    @Override
    public void setVisibleEvent(Instruction source, boolean isVisible) {
        if (listeners.getListenerCount() != 0) {
            OperationListener operation[] = listeners.getListeners(OperationListener.class);
            for (OperationClass.OperationListener op : operation) {
                this.setVisible(isVisible);
                op.componentEvent(isVisible);
            }
        }
    }
    
    @Override
    public void setDeplacable(boolean isDeplacable) {
        this.isDeplacable = isDeplacable;
        array.setDeplacable(isDeplacable);
        for (Component cmpt : listePointer.getComponents()) {
            ((OperationAdapter) cmpt).setDeplacable(isDeplacable);
        }
    }
    
    public boolean isDeplacable() {
        return this.isDeplacable;
    }
    
    private boolean canMove(Component c) {
        Component ancestor1 = SwingUtilities.getAncestorNamed("###declaration###", c);
        Component ancestor2 = SwingUtilities.getAncestorNamed("###declaration###", this);
        Component ancestor3 = SwingUtilities.getAncestorNamed("###execution###", c);
        Component ancestor4 = SwingUtilities.getAncestorNamed("###execution###", this);
        return ((ancestor1 == ancestor2 && ancestor1 != null)
                || (ancestor1 == null && ancestor3 == null))
                || (ancestor3 == ancestor4);
    }
    
}
