package interpreteurgraphic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import interpreteurgraphic.OperationClass.OperationAdapter;
import java.awt.BorderLayout;
import xmlstructure.Instruction;
import xmlstructure.Affectation;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import xmlstructure.Instruction.enumType;
import xmlstructure.Message;
import xmlstructure.Variable;

/**
 *
 * @author Asus
 */
public class Fenetre extends JFrame implements ComponentListener, ActionListener {

    public static Fleche flechePanel = new Fleche();
    private SourcePanel sourcePanel;
    private final JButton buttonNext, buttonPrev;
    private int flecheNumber;
    private final JPanel mainPanel, declarationPanel, globalPane;
    private final JScrollPane globalScrollPane, declarationScrollPane;
    private final List<Instruction> listInstruction;
    private final Color colorbg;

    public Fenetre(String title, int largeur, int hauteur, Map<Integer, Instruction> hashDeclaration) {
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setSize(largeur, hauteur);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.flecheNumber = 0;

        this.colorbg = Color.getHSBColor((float) (212 / 256.0), (float) (17 / 256.0), (float) (67 / 256.0));

        this.globalPane = new JPanel();
        this.globalPane.setLayout(new BorderLayout());
        this.globalPane.setLocation(0, 0);
        this.globalPane.setOpaque(true);
        this.globalPane.setBackground(colorbg);

        this.globalScrollPane = new JScrollPane(this.globalPane, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.globalScrollPane.setLocation(300, 29);
        this.globalScrollPane.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, colorbg));
        
        
          

        Border margin = BorderFactory.createMatteBorder(3, 0, 0, 0, new Color(109, 170, 193));
        Border declarationTitleBorder = BorderFactory.createTitledBorder(margin, "Declaration global", TitledBorder.CENTER, TitledBorder.TOP, this.getFont(), Color.WHITE);
        Border mainTitleBorder = BorderFactory.createTitledBorder(margin, "Execution", TitledBorder.CENTER, TitledBorder.TOP, this.getFont(), Color.WHITE);
        Border declarationMargin = BorderFactory.createCompoundBorder(declarationTitleBorder, BorderFactory.createMatteBorder(0, 0, 20, 0, colorbg));
        this.declarationPanel = new JPanel();
        this.declarationPanel.setName("###declaration###");

        this.declarationPanel.setLayout(new WrapLayout(FlowLayout.LEFT));
        this.declarationPanel.setOpaque(true);
        this.declarationPanel.setBackground(colorbg);
        this.declarationPanel.setMinimumSize(new Dimension(this.getWidth(), 300));
        this.declarationPanel.setBorder( declarationMargin);
        this.declarationPanel.addComponentListener(this);
        
        this.declarationScrollPane = new JScrollPane(this.declarationPanel, JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.declarationScrollPane.setLocation(300, 15);

        this.mainPanel = new JPanel();
        this.mainPanel.setName("###execution###");
        this.mainPanel.setLayout(new BorderLayout());
        this.mainPanel.setOpaque(true);
        this.mainPanel.setBorder(mainTitleBorder);
        this.mainPanel.setBackground(colorbg);

        AdjustmentListener adjustement = new AdjustmentListener() {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                componentResized(null);
            }
        };

        this.globalScrollPane.getHorizontalScrollBar().addAdjustmentListener(adjustement);
        this.globalScrollPane.getVerticalScrollBar().addAdjustmentListener(adjustement);
        
        this.declarationScrollPane.getHorizontalScrollBar().addAdjustmentListener(adjustement);

        this.buttonNext = new JButton("Suivant");
        this.buttonNext.setSize(new Dimension(120, 25));
        this.buttonNext.addActionListener(this);        

        Fenetre.flechePanel.setLocation(300, 15);

        this.buttonPrev = new JButton("Revenir");
        this.buttonPrev.setSize(new Dimension(150, 25));
        this.buttonPrev.addActionListener(this);
        this.buttonPrev.setEnabled(false);

        this.globalPane.add(this.declarationScrollPane, BorderLayout.NORTH);
        this.globalPane.add(this.mainPanel);

        this.getContentPane().add(Fenetre.flechePanel);
        this.getContentPane().add(this.globalScrollPane);
        this.getContentPane().add(this.buttonNext);
        this.getContentPane().add(this.buttonPrev);

        this.getContentPane().setBackground(colorbg);
        this.setVisible(true);
        this.addComponentListener(this);
        this.listInstruction = new ArrayList<Instruction>(hashDeclaration.values());
        

    }

    public void chargement(String fichierSource[]) {
        this.sourcePanel = new SourcePanel(fichierSource);
        this.sourcePanel.setLocation(0, 30);
        this.sourcePanel.setSize(this.mainPanel.getX(), this.getHeight());
        this.getContentPane().add(sourcePanel);
        this.sourcePanel.repaint();
        this.revalidate();

        //initialisation position fleche
        this.flecheNumber = 0;
        this.updateSourcePanel(-1, flecheNumber);
        //force la mise a jour des positionnements
        componentResized(null);
    }

    @Override
    public void componentResized(ComponentEvent e) {
        if (this.mainPanel != null) {
            this.declarationScrollPane.setPreferredSize(new Dimension(this.getWidth() - this.globalScrollPane.getX() - 15, this.declarationPanel.getHeight()));
            this.globalScrollPane.setSize(this.getWidth() - this.globalScrollPane.getX() - 15, this.getHeight() - 65);
            Fenetre.flechePanel.setSize(this.getWidth() - Fenetre.flechePanel.getX(), this.getHeight());
            this.getContentPane().revalidate();
            this.getContentPane().repaint();
        }
        if (this.sourcePanel != null) {
            this.sourcePanel.setSize(this.globalScrollPane.getX() + 1, this.getHeight() - 85);
            if (this.buttonPrev != null) {
                this.buttonPrev.setLocation(this.sourcePanel.getX() + 30, (this.sourcePanel.getHeight() + 35));
            }
            if (this.buttonNext != null) {
                this.buttonNext.setLocation(this.sourcePanel.getX() + this.buttonPrev.getWidth() + 30, (this.sourcePanel.getHeight() + 35));
            }
        }
    }

    @Override
    public void componentMoved(ComponentEvent e) {
    }

    @Override
    public void componentShown(ComponentEvent e) {
    }

    @Override
    public void componentHidden(ComponentEvent e) {
    }

    private void updateSourcePanel(int idPrec, int idSuiv) {
        Instruction instructionPrec = null, instructionSuiv = null;
        if (0 <= idPrec && idPrec < listInstruction.size()) {
            instructionPrec = this.listInstruction.get(idPrec);
        }
        if (0 <= idSuiv && idSuiv < listInstruction.size()) {
            instructionSuiv = this.listInstruction.get(idSuiv);
        }

        this.sourcePanel.update(instructionPrec != null ? instructionPrec.getLigne() - 1 : -1,
                instructionPrec != null ? instructionPrec.getFichier() : null,
                instructionSuiv != null ? instructionSuiv.getLigne() - 1 : -1,
                instructionSuiv != null ? instructionSuiv.getFichier() : null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (Boolean.compare(e.getSource().equals(this.buttonPrev), false)) {
            case 0: {
                if (showInstruction(flecheNumber)) {
                    if (!this.buttonPrev.isEnabled()) {
                        this.buttonPrev.setEnabled(true);
                    }
                    this.updateSourcePanel(flecheNumber, ++flecheNumber);
                    if (flecheNumber >= listInstruction.size()) {
                        this.buttonNext.setEnabled(false);
                        flecheNumber = listInstruction.size();
                    }
                }
                componentResized(null);
                break;
            }
            case 1: {
                if (retourArriere(flecheNumber - 1)) {
                    if (!this.buttonNext.isEnabled()) {
                        this.buttonNext.setEnabled(true);
                    }
                    this.updateSourcePanel(--flecheNumber - 1, flecheNumber);
                    if (flecheNumber < 0) {
                        this.buttonPrev.setEnabled(false);
                        flecheNumber = 0;
                    }
                }
                componentResized(null);
                break;
            }
        }
    }

    /*Cette méthode affiche l'instruction ayant l'identifiant id,
     et appel la suppression de flèche temporaire de l'instruction précedente*/
    private boolean showInstruction(int id) {
        if (!this.listInstruction.isEmpty()) {
            if (0 <= id && id < this.listInstruction.size()) {
                OperationAdapter operation;
                Instruction instruction = this.listInstruction.get(id);
                removeFlecheTemporaire(id - 1);
                switch (instruction.getTypeInstruction()) {
                    case affectation:
                        /*si l'instruction est une affectation on effectue l'affectation et 
                         on change la couleur de son modèle graphique en rouge*/
                        ((Affectation) instruction).affect();
                        instruction.produireComposant().setForeground(new Color(255, 51, 51));
                        instruction.produireComposant().setVisible(true);
                        break;
                    case message:
                        /*si l'instruction est un message, celui-ci est recupéré et affiché*/
                        System.out.println(((Message) instruction).getMessage());
                        break;
                    case array:
                    case struct:
                    case pointer:
                        instruction.produireComposant().setForeground(new Color(255, 51, 51));
                    case variable: {
                        /*si l'instruction est une variable primitif */
                        if ("@return".equals(((Variable) instruction).getNom())) {
                            /*si cet instruction est un return on rend visible le modèle graphique du stacklist associé
                             via un VisibleEvent ainsi tout le stacklist est affiché, puis on change la couleur du modèle graphique
                             du return en rouge */
                            operation = (OperationAdapter) instruction.produireComposant();
                            operation.setVisibleEvent(instruction, true);
                            instruction.produireComposant().setForeground(new Color(255, 51, 51));
                        } else if (!"".equals(((Variable) instruction).getValeur().toString())) {
                            /*Si cet instruction est une variable ayant une valeur
                             on change la couleur de son modèle graphique en rouge*/
                            instruction.produireComposant().setForeground(new Color(255, 51, 51));
                        }
                    }
                    break;
                }
                if (instruction.getTypeInstruction() != enumType.message) {
                    /*si le modèle graphique de l'instruction n'est pas présente (visible on non) on y ajoute*/
                    if (!mainPanel.isAncestorOf(instruction.produireComposant())
                            && !declarationPanel.isAncestorOf(instruction.produireComposant())) {
                        if (enumType.stacklist == instruction.getTypeInstruction()) {
                            /*si cet instruction est un stacklist il sera ajouté à la partie fonction*/
                            mainPanel.add(instruction.produireComposant(), BorderLayout.NORTH);
                        } else {
                            /*sinon cet instruction est ajouté à la partie déclaration*/
                            declarationPanel.add(instruction.produireComposant());
                        }
                    }
                    instruction.produireComposant().setVisible(true);
                }
                return true;
            }
        }
        return false;
    }

    /*Cette méthode appel la suppression de flèche temporaire de l'instruction dont l'identifiant est id,
     appelle l'annulation d'une affectation et ou appelle l'affichage du modèle graphique de l'instruction précedente*/
    private boolean retourArriere(int id) {
        if (!this.listInstruction.isEmpty()) {
            Instruction instruction;
            OperationAdapter operation;
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                switch (instruction.getTypeInstruction()) {
                    case affectation:
                        /*Annulation d'une affectation*/
                        ((Affectation) instruction).desaffect();
                        operation = (OperationAdapter) instruction.produireComposant();
                        operation.setVisibleEvent(instruction, true);
                        /*Suppresion de flèche temporaire sur les variables copiées*/
                        removeFlecheTemporaire(id);
                        /*Affichage de l'instruction précédente*/
                        showInstruction(id - 1);
                        break;
                    case message:
                        break;
                    default:
                        operation = (OperationAdapter) instruction.produireComposant();
                        operation.setVisibleEvent(instruction, true);
                        /*Annulation de l'affichage de l'instruction courante et affichage de l'instruction précédente*/
                        instruction.produireComposant().setVisible(false);
                        showInstruction(id - 1);
                        break;
                }
                return true;
            }
        }
        return false;
    }

    /*Cette méthode efface l'affichage des flèches sur les variables copiées (int a = b)*/
    public void removeFlecheTemporaire(int id) {
        if (!this.listInstruction.isEmpty()) {
            Instruction instruction;
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                switch (instruction.getTypeInstruction()) {
                    case affectation:
                        ((Affectation) instruction).removeFlecheTemporaire();
                        instruction.produireComposant().setForeground(Color.WHITE);
                        break;
                    case message:
                        break;
                    case array:
                    case struct:
                    case pointer:
                    case variable:
                        if ("@return".equals(((Variable) instruction).getNom())) {
                            instruction.produireComposant().setVisible(false);
                            OperationAdapter operation;
                            operation = (OperationAdapter) instruction.produireComposant();
                            operation.setVisibleEvent(instruction, false);
                        }
                        instruction.produireComposant().setForeground(Color.WHITE);
                        break;
                }
            }
        }
    }

}
