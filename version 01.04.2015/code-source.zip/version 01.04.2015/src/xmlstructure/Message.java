/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xmlstructure;

/**
 *
 * @author Asus
 */
public class Message extends Instruction {
    String message;
    public Message(String ident, String ligne, String fichier, String message) {
        super(ident, ligne, fichier);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
    
     @Override
    public enumType getTypeInstruction() {
        return enumType.message;
    }
    
}
