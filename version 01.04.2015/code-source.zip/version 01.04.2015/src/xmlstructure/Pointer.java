package xmlstructure;

import interpreteurgraphic.ArrayFigure;
import interpreteurgraphic.Composant;
import interpreteurgraphic.Fenetre;
import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import xmlstructure.Variable.MemorySet;

public class Pointer extends Variable implements Serializable, MemorySet {

    private Array array;
    private final Composant composant;

    public Pointer(Array array) {
        super(String.valueOf(array.getIdent()), array.getType(), array.getNom(), "", String.valueOf(array.getLigne()), array.getFichier());
        this.type = array.type;
        this.nom = array.nom;
        this.array = array;
        this.composant = new Composant(getType() + " " + nom);
        this.composant.setVisible(true);
        this.updateComposant(false);
    }

    /*Initialisation d'un tableau de structure*/
    @Override
    public void set(Array array) {
        updateComposant(true);
        this.array.setPointer(true);
        this.array.set(array);
        updateComposant(false);
    }

    @Override
    public void set(Variable variable) {
        updateComposant(true);
        this.array.setPointer(true);
        this.array.set(variable);
        updateComposant(false);
    }

    @Override
    public void set(Pointer p) {
        updateComposant(true);
        this.array.setPointer(true);
        this.array.set(p.array);
        updateComposant(false);
    }

    @Override
    public void set(Variable[] listVariable) {
        updateComposant(true);
        this.array.setPointer(false);
        this.array.set(listVariable);
        updateComposant(false);
    }

    @Override
    public void setValeur(String valeur) {
        this.array.setValeur(valeur);
    }

    @Override
    public void setValeur(StringBuilder valeur) {
        this.array.setValeur(valeur);
    }

    @Override
    public Variable getVariable(String name) {
        if (this.nom.equals(name)) {
            return this;
        }
        return array.getVariable(name, this.nom);
    }

    @Override
    public Variable getVariable(String name, String parent) {
        return array.getVariable(name, parent);
    }

    @Override
    public String getNomComplet(String parent) {
        return array.getNomComplet(parent);
    }

    @Override
    public StringBuilder getValeur() {
        return array.getValeur();
    }

    @Override
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();  
        ((Pointer)copied).array = (Array) array.copie();
        out.close();
        bos.close();
        bis.close();
        in.close();
        return copied;
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.pointer;
    }

    @Override
    public void setPointer(boolean isPointer) {
        array.updateComposant();
    }

    @Override
    public String toString() {
        return array.getType() + " " + array.getNom() + " " + this.array.getValeur();
    }

    @Override
    public Component produireComposant() {
        return this.array.produireComposant();
    }

    private void updateComposant(boolean invalid) {
        if (invalid) {
            ((ArrayFigure) this.array.produireComposant()).removePointer(composant);
        } else {
            ((ArrayFigure) this.array.produireComposant()).addPointer(composant);
        }
    }        
}
