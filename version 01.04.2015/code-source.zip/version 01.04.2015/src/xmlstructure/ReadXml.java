package xmlstructure;

import interpreteurgraphic.Fenetre;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import org.jdom2.*;
import org.jdom2.input.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import xmlstructure.Instruction.enumType;

public class ReadXml {

    private final Map<Integer, Instruction> hashDeclaration;
    private final Map<Integer, Instruction> hashExecution;
    private Element racine;

    public ReadXml() {
        hashDeclaration = new HashMap<Integer, Instruction>();
        hashExecution = new HashMap<Integer, Instruction>();
    }

    void chargement_xml(String file) {
        try {
            SAXBuilder sxb = new SAXBuilder();
            Document document = sxb.build(new File(file));
            racine = document.getRootElement();
            extraire_instruction(racine.getChild("declaration"), true);
            extraire_instruction(racine.getChild("execution"), true);
            hashDeclaration.clear();
        } catch (JDOMException ex) {
            System.out.println("" + ex.getMessage());
            System.exit(-3);
        } catch (IOException ex) {
            System.out.println("" + ex.getMessage());
            System.exit(-3);
        } catch (ClassNotFoundException ex) {
            System.out.println("" + ex.getMessage());
            System.exit(-3);
        }
    }

    void chargement_xml(BufferedReader input) {
        try {
            SAXBuilder sxb = new SAXBuilder();
            Document document = sxb.build(input);
            racine = document.getRootElement();
            extraire_instruction(racine.getChild("declaration"), true);
            extraire_instruction(racine.getChild("execution"), true);
            hashDeclaration.clear();
        } catch (JDOMException ex) {
            System.out.println("" + ex.getMessage());
            System.exit(-3);
        } catch (IOException ex) {
            System.out.println("" + ex.getMessage());
            System.exit(-3);
        } catch (ClassNotFoundException ex) {
            System.out.println("" + ex.getMessage());
            System.exit(-3);
        }
    }

    private Variable getVariableHashMap(String id) {
        Variable variable;
        variable = (Variable) hashDeclaration.get(Integer.parseInt(id));
        return variable;
    }

    private Variable getVariableHashMap(String type, String name) {
        Variable variable = null;
        for (Map.Entry<Integer, Instruction> entry : hashDeclaration.entrySet()) {
            if (entry.getValue() instanceof Variable) {
                variable = (Variable) entry.getValue();
                if (variable.getType().equals(type) && variable.getNom().equals(name)) {
                    return variable;
                }
            }
        }
        return variable;
    }

    private Instruction extraire_instruction(Element e, boolean sauvegarder) throws IOException, ClassNotFoundException {
        Stacklist bloc;
        Structure structModele;
        Affectation affectation;
        Instruction instruction;
        List<Instruction> listeInstruction;
        List<Element> noeudMembre;
        Array array;
        boolean isPointer = false;
        List<Variable> listVariable = null;
        Variable source = null, destination, variable = null;
        String type;
        switch (enumType.getTypeOf(e.getName())) {
            case affectation: {
                if (e.getAttributeValue("nsrc") != null) {
                    source = getVariableHashMap(e.getAttributeValue("id_src"));
                }
                destination = getVariableHashMap(e.getAttributeValue("id_dest"));
                /*affectaction de variable primitif(int, char, double, ...)*/
                if (e.getAttributeValue("typeid").equals("primitif") || e.getContentSize() == 0) {
                    String ascii = e.getAttributeValue("ascii");
                    ascii = ascii == null ? "" : "@" + ascii;
                    affectation = new Affectation(e.getAttributeValue("id"), e.getAttributeValue("line"),
                            e.getAttributeValue("file"), source, destination, e.getAttributeValue("typeid"),
                            e.getAttributeValue("value") + ascii, e.getAttributeValue("ndest"), e.getAttributeValue("nsrc"));
                } else {
                    /*affectation de variable complexe (array, pointeur, ...)*/
                    listVariable = getListValue(e);/*récupération de la liste de var s'il n'y a pas de source*/

                    affectation = new Affectation(e.getAttributeValue("id"), e.getAttributeValue("line"),
                            e.getAttributeValue("file"), source, destination, e.getAttributeValue("typeid"), listVariable,
                            e.getAttributeValue("ndest"), e.getAttributeValue("nsrc"));
                }
                hashExecution.put(affectation.getIdent(), affectation);
                return affectation;
            }
            case stacklist:
                listeInstruction = new ArrayList<Instruction>();
                switch (enumType.getTypeOf(e.getAttributeValue("typeid"))) {
                    case fonction:
                        listVariable = new ArrayList<Variable>();
                        if (e.getChild("return") != null) {
                            variable = (Variable) extraire_instruction(e.getChild("return"), true);
                            e.removeChild("return");
                        }
                        if ((noeudMembre = e.getChildren("param")) != null) {
                            for (Element membre : noeudMembre) {
                                instruction = (Instruction) extraire_instruction(membre, true);
                                listVariable.add((Variable) instruction);
                            }
                            e.removeChildren("param");
                        }
                    default:
                        if (e.getChild("return") != null && variable == null) {
                            variable = (Variable) extraire_instruction(e.getChild("return"), true);
                            e.removeChild("return");
                        }
                        if ((noeudMembre = e.getChildren()) != null) {
                            for (Element membre : noeudMembre) {
                                instruction = (Instruction) extraire_instruction(membre, true);
                                listeInstruction.add(instruction);
                            }
                        }
                        break;
                }
                bloc = new Stacklist(e.getAttributeValue("id"), variable, listVariable, listeInstruction, e.getAttributeValue("type"), e.getAttributeValue("typeid"),
                        e.getAttributeValue("line"), e.getAttributeValue("file"), e.getAttributeValue("name"));
                hashExecution.put(bloc.getIdent(), bloc);
                return bloc;
            case retour:
            case parametre:
            case variable: {
                switch (enumType.getTypeOf(e.getAttributeValue("typeid"))) {
                    case primitif:
                        String ascii = e.getAttributeValue("ascii");
                        ascii = ascii == null ? "" : "@" + ascii;
                        variable = new Variable(e.getAttributeValue("id"), e.getAttributeValue("type"),
                                e.getAttributeValue("name"), e.getAttributeValue("value") + ascii,
                                e.getAttributeValue("line"), e.getAttributeValue("file"));
                        break;
                    case struct:
                        if ((structModele = (Structure) getVariableHashMap(e.getAttributeValue("type"), "")) == null) {
                            structModele = new Structure(e.getAttributeValue("id"), e.getAttributeValue("type"),
                                    e.getAttributeValue("name"), e.getAttributeValue("line"), e.getAttributeValue("file"));
                            noeudMembre = e.getChildren();
                            for (Element membre : noeudMembre) {
                                structModele.addMembre((Variable) extraire_instruction(membre, false));
                            }
                        } else {
                            structModele = (Structure) structModele.copie();
                            structModele.setNom(e.getAttributeValue("name"));
                            structModele.setIdent(e.getAttributeValue("id"));
                            structModele.setLigne(e.getAttributeValue("line"));
                            noeudMembre = e.getChildren();
                            if (!noeudMembre.isEmpty()) {
                                structModele.clearMembre();
                            }
                            for (Element membre : noeudMembre) {
                                structModele.addMembre((Variable) extraire_instruction(membre, false));
                            }
                        }
                        variable = structModele;
                        break;
                    case pointer:
                        isPointer = true;
                    case array:
                        type = e.getAttributeValue("type");
                        if (e.getChild("var") != null) {
                            listVariable = getListValue(e);
                            array = new Array(e.getAttributeValue("id"), e.getAttributeValue("type"),
                                    e.getAttributeValue("name"), isPointer, e.getAttributeValue("line"),
                                    e.getAttributeValue("file"), listVariable);
                        } else if (!isPointer && type.contains("struct")/*tableau de structure*/) {
                            structModele = (Structure) getVariableHashMap(type.replaceAll("\\[\\]", "").trim(), "");
                            if (structModele != null) {
                                structModele = (Structure) structModele.copie();
                                structModele.setNom(e.getAttributeValue("name"));
                            }
                            array = new Array(e.getAttributeValue("id"), e.getAttributeValue("type"),
                                    e.getAttributeValue("name"), isPointer, e.getAttributeValue("line"),
                                    e.getAttributeValue("file"), structModele, Integer.parseInt(e.getAttributeValue("count")));
                        } else {
                            String cout = e.getAttributeValue("count");
                            array = new Array(e.getAttributeValue("id"), e.getAttributeValue("type"),
                                    e.getAttributeValue("name"), isPointer, e.getAttributeValue("line"),
                                    e.getAttributeValue("file"), Integer.parseInt(cout == null ? "0" : cout));
                        }
                        variable = (isPointer) ? new Pointer(array) : array;
                        break;
                }
                if (e.getAttributeValue("nsrc") != null) {
                    source = getVariableHashMap(e.getAttributeValue("id_src"));
                    //variable.setValeur("");
                    affectation = new Affectation(e.getAttributeValue("id"), e.getAttributeValue("line"),
                            e.getAttributeValue("file"), source, variable, e.getAttributeValue("typeid"), source.getValeur().toString(),
                            variable.getNom(), e.getAttributeValue("nsrc"));
                    if (sauvegarder) {
                        hashDeclaration.put(variable.getIdent(), variable);
                        hashExecution.put(variable.getIdent(), affectation);
                    }
                } else if (sauvegarder) {
                    hashDeclaration.put(variable.getIdent(), variable);
                    hashExecution.put(variable.getIdent(), variable);
                }
                return variable;
            }
            case message:
                instruction = new Message(e.getAttributeValue("id"), e.getAttributeValue("line"),
                        e.getAttributeValue("file"), e.getContent(0).getValue());
                hashExecution.put(instruction.getIdent(), instruction);
                return instruction;
        }
        if (sauvegarder) {
            List<Element> list_element = e.getChildren();
            for (Element element : list_element) {
                extraire_instruction(element, sauvegarder);
            }
        }
        return null;
    }

    private List<Variable> getListValue(Element e)
            throws IOException, ClassNotFoundException {
        //int i = Integer.parseInt(e.getAttributeValue("count"));
        List<Element> noeudMembre = e.getChildren();
        //if (i == 0 && noeudMembre != null) {
        int i = noeudMembre.size();
        //}
        List<Variable> variable = Arrays.asList(new Variable[i]);
        for (i = 0; i < noeudMembre.size(); i++) {
            Element element = noeudMembre.get(i);
            variable.set(i, (Variable) extraire_instruction(element, false));
        }
        return variable;
    }

    public Map<Integer, Instruction> getHashExecution() {
        return hashExecution;
    }

    public static Thread redirectStdin(final OutputStream writer, final Scanner scan) {
        Thread T = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    String input = scan.nextLine();
                    input += "\n";
                    try {
                        writer.write(input.getBytes());
                        writer.flush();
                    } catch (IOException e) {
                        System.out.println("" + e.getMessage());
                    }
                }
            }
        });
        T.start();
        return T;
    }

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Veuillez passez en argument les fichiers C suivi potentiellement des args liées aux fichiers C "
                    + "ou le fichier xml à afficher");
            return;
        }
        ReadXml readxml = new ReadXml();
        try {
            Path picoc = Paths.get("picoc");
            Path picocExe = Paths.get("picoc.exe");
            if (!Files.isExecutable(picoc) && !Files.isExecutable(picocExe)) {
                System.out.println("Erreur l'executable picoc est introuvable");
                System.out.print("Solution 1: si l'executable picoc existe");
                System.out.println(" deplacer l'executable picoc dans le meme repertoire que ce programme");
                System.out.print("Solution 2: si l'executable picoc n'existe pas");
                System.out.println(" compiler via l'utilitaire make le code source de picoc");
                System.exit(-2);
            }
            String programme[] = new String[args.length + 1];
            programme[0] = "./picoc";
            System.arraycopy(args, 0, programme, 1, args.length);
            ProcessBuilder pb = new ProcessBuilder(programme);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            Thread Thread = redirectStdin(process.getOutputStream(), new Scanner(System.in));
            //process.redirectOutput(new FileOutputStream(new File(outfile));
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            System.out.println("Chargement ... Patientez");
            readxml.chargement_xml(reader);
            int exitVal = process.waitFor();
            if (exitVal != 0) {
                process = pb.start();
                reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.contains("<") && !line.contains(">")) {
                        System.out.println(line);
                    }
                }
                exitVal = process.waitFor();
                System.out.println("Code d'erreur " + exitVal);
                System.exit(-1);
            } else {
                System.out.println("Chargement réussi !!! ");
                Fenetre fenetre = new Fenetre("Ma fenetre", 1040, 580, readxml.getHashExecution());
                fenetre.chargement(args);
                fenetre.revalidate();
            }
            Thread.interrupt();

        } catch (IOException e) {
            System.out.println(e.toString());
        } catch (InterruptedException e) {
            System.out.println(e.toString());
        }

    }

}
