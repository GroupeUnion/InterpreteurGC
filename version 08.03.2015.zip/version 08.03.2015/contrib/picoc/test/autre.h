#ifdef H_AUTRE
#define H_AUTRE
void function();

#endif