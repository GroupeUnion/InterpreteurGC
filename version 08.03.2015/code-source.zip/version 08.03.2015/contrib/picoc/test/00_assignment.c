#include <stdio.h>

int a;
a = 42;
int b = 64;
int c = 12, d = 34;

int main() 
{
	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d, %d\n", c, d);
	return 0;
}
