#include <stdlib.h>
#include "autre.h"
int s = 0;
int main()
{
  int a, b, c, i;
  a = 5;
  b = 8;
  c = 20;
  function();
  return 0;
}	
