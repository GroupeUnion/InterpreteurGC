#include "autre.h"
int j = 0;

void function()
{
	int h = 0;
}