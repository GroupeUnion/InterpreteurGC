#include <stdlib.h>
#include "autre.h"
int s = 0;
char copy[20];
int main()
{
  int a, b, c, i;
  a = 5;
  b = 8;
  c = 20;
  function();
  strcpy(mot, "Bonjour");
  strcpy(copy, mot);
  return 0;
}	
