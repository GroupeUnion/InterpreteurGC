package interpreteurgraphic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.BorderLayout;
import xmlstructure.Instruction;
import xmlstructure.Affectation;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import xmlstructure.Instruction.enumType;
import static xmlstructure.Instruction.enumType.eTypeVariable;
import xmlstructure.Message;
import xmlstructure.Variable;

/**
 * Fenêtre graphique
 *
 * @author mahamat
 */
public class Fenetre extends javax.swing.JFrame implements ComponentListener, ActionListener {

    /**
     * Gestionnaire graphique de fleche.
     */
    public static Fleche flechePanel = new Fleche();
    public static final JLabel labelErrorMessage = new JLabel("");
    private SourcePanel sourcePanel; /*Gestionnaire graphique de code source.*/

    private final JButton buttonNext, buttonPrev;
    private int identifiant;
    private final JPanel mainPanel, declarationPanel, globalPane;
    private final JScrollPane globalScrollPane, declarationScrollPane;
    private final List<Instruction> listInstruction;
    private final Color colorbg;

    /**
     * @param title Titre de la fenêtre
     * @param largeur Largeur par défaut de la fenêtre
     * @param hauteur Hauteur par défaut de la fenêtre
     * @param hashExecution Table de hachage des instructions à exécuter
     */
    public Fenetre(String title, int largeur, int hauteur, Map<Integer, Instruction> hashExecution) {
        this.setTitle(title);
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setSize(largeur, hauteur);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.identifiant = 0;

        this.colorbg = Color.getHSBColor((float) (212 / 256.0), (float) (17 / 256.0), (float) (67 / 256.0));

        this.globalPane = new JPanel();
        this.globalPane.setLayout(new BorderLayout());
        this.globalPane.setLocation(0, 0);
        this.globalPane.setOpaque(true);
        this.globalPane.setBackground(colorbg);
        UIManager.put("ScrollBarUI", "javax.swing.plaf.basic.BasicScrollBarUI");
        UIManager.put("ButtonUI", "javax.swing.plaf.basic.BasicButtonUI");

        this.globalScrollPane = new JScrollPane(this.globalPane, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.globalScrollPane.setLocation(300, 29);
        this.globalScrollPane.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, colorbg));

        Border margin = BorderFactory.createMatteBorder(3, 0, 0, 0, new Color(109, 170, 193));
        Border declarationTitleBorder = BorderFactory.createTitledBorder(margin, "Declaration global", TitledBorder.CENTER, TitledBorder.TOP, this.getFont(), Color.WHITE);
        Border mainTitleBorder = BorderFactory.createTitledBorder(margin, "Execution", TitledBorder.CENTER, TitledBorder.TOP, this.getFont(), Color.WHITE);
        Border declarationMargin = BorderFactory.createCompoundBorder(declarationTitleBorder, BorderFactory.createMatteBorder(0, 0, 20, 0, colorbg));
        Border mainMargin = BorderFactory.createCompoundBorder(mainTitleBorder, BorderFactory.createMatteBorder(0, 0, 30, 0, colorbg));
        this.declarationPanel = new JPanel();
        this.declarationPanel.setName("###declaration###");

        this.declarationPanel.setLayout(new WrapLayout(FlowLayout.LEFT));
        this.declarationPanel.setOpaque(true);
        this.declarationPanel.setBackground(colorbg);
        this.declarationPanel.setMinimumSize(new Dimension(this.getWidth(), 300));
        this.declarationPanel.setBorder(declarationMargin);
        this.declarationPanel.addComponentListener(this);

        this.declarationScrollPane = new JScrollPane(this.declarationPanel, JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        this.declarationScrollPane.setLocation(300, 15);

        this.mainPanel = new JPanel();
        this.mainPanel.setName("###execution###");
        this.mainPanel.setLayout(new BorderLayout());
        this.mainPanel.setOpaque(true);
        this.mainPanel.setBorder(mainMargin);
        this.mainPanel.setBackground(colorbg);

        AdjustmentListener adjustement = new AdjustmentListener() {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                componentResized(null);
            }
        };

        this.globalScrollPane.getHorizontalScrollBar().addAdjustmentListener(adjustement);
        this.globalScrollPane.getVerticalScrollBar().addAdjustmentListener(adjustement);
        this.globalScrollPane.getHorizontalScrollBar().setUnitIncrement(100);
        this.globalScrollPane.getVerticalScrollBar().setUnitIncrement(100);

        this.declarationScrollPane.getHorizontalScrollBar().addAdjustmentListener(adjustement);
        this.declarationScrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(10, 15));
        this.declarationScrollPane.getHorizontalScrollBar().setUnitIncrement(200);
        this.buttonNext = new JButton("Suivant");
        this.buttonNext.setSize(new Dimension(120, 25));
        this.buttonNext.addActionListener(this);

        Fenetre.flechePanel.setLocation(300, 15);
        Fenetre.labelErrorMessage.setLocation(10, 5);
        Fenetre.labelErrorMessage.setText("Bienvenue");
        Fenetre.labelErrorMessage.setOpaque(false);
        Fenetre.labelErrorMessage.setForeground(Color.WHITE);

        this.buttonPrev = new JButton("Revenir");
        this.buttonPrev.setSize(new Dimension(150, 25));
        this.buttonPrev.addActionListener(this);
        this.buttonPrev.setEnabled(false);

        this.globalPane.add(this.declarationScrollPane, BorderLayout.NORTH);
        this.globalPane.add(this.mainPanel);

        this.getContentPane().add(Fenetre.flechePanel);
        this.getContentPane().add(this.globalScrollPane);
        this.getContentPane().add(this.buttonNext);
        this.getContentPane().add(this.buttonPrev);
        this.getContentPane().add(Fenetre.labelErrorMessage);

        this.getContentPane().setBackground(colorbg);
        this.setVisible(true);
        this.addComponentListener(this);
        this.listInstruction = new ArrayList<Instruction>(hashExecution.values());

    }

    /**
     * Crée un objet {@link SourcePanel} et l'ajoute à la fenêtre graphique, le
     * tableau des chemins d'accès vers les fichiers C lui sont passés en
     * paramètre du
     * {@link SourcePanel#SourcePanel(java.lang.String[]) constructeur}.
     *
     * @param fichierSource Tableau des chemins d'accès vers les fichiers C
     */
    public void chargement(String fichierSource[]) {
        this.sourcePanel = new SourcePanel(fichierSource);
        this.sourcePanel.setLocation(0, 30); //Position le gestionnaire en x = 0, y = 30
        this.sourcePanel.setSize(this.mainPanel.getX(), this.getHeight()); //Modifie la taille
        this.getContentPane().add(sourcePanel); //ajoute le composant à  la fenêtre graphique
        this.sourcePanel.repaint();

        //initialisation position fleche
        this.identifiant = 0;
        this.updateSourcePanel(-1, identifiant);
        //force la mise a jour des positionnements
        componentResized(null);
    }

    /**
     * Signal le redimensionnement d'un composant graphique.
     *
     * @param component Objet d'évènement de bas niveau qui indique le
     * redimentionné.
     */
    @Override
    public void componentResized(ComponentEvent component) {
        if (this.mainPanel != null) {
            /*Redimensionnement de tous les composants principaux. */
            this.declarationScrollPane.setPreferredSize(new Dimension(this.getWidth() - this.globalScrollPane.getX() - 15, this.declarationPanel.getHeight()));
            this.globalScrollPane.setSize(this.getWidth() - this.globalScrollPane.getX() - 15, this.getHeight() - 65);
            Fenetre.flechePanel.setSize(this.getWidth() - Fenetre.flechePanel.getX(), this.getHeight());
            Fenetre.labelErrorMessage.setSize(this.getWidth(), 20);
            this.getContentPane().revalidate();
            this.getContentPane().repaint();
        }
        if (this.sourcePanel != null) {
            /*Redimensionnement du gestionnaire d'affichage de code C.*/
            this.sourcePanel.setSize(this.globalScrollPane.getX() + 1, this.getHeight() - 85);
            if (this.buttonPrev != null) {
                this.buttonPrev.setLocation(this.sourcePanel.getX() + 30, (this.sourcePanel.getHeight() + 35));
            }
            if (this.buttonNext != null) {
                this.buttonNext.setLocation(this.sourcePanel.getX() + this.buttonPrev.getWidth() + 30, (this.sourcePanel.getHeight() + 35));
            }
        }
    }

    /**
     * Signal le déplacement d'un composant graphique.
     *
     * @param component Objet d'évènement de bas niveau qui indique le component
     * déplacé.
     */
    @Override
    public void componentMoved(ComponentEvent component) {
    }

    /**
     * Signal l'affichage d'un composant graphique.
     *
     * @param component Objet d'évènement de bas niveau qui indique le component
     * rendu visible.
     */
    @Override
    public void componentShown(ComponentEvent component) {
    }

    /**
     * Signal l'effacement d'un composant graphique.
     *
     * @param component Objet d'évènement de bas niveau qui indique le component
     * rendu invisible.
     */
    @Override
    public void componentHidden(ComponentEvent component) {
    }

    /**
     * Appelle la mise à jour de la position des flèches soulignant
     * l'instruction précédente et l'instruction courante, via la méthode
     * {@link SourcePanel#update  update} de la classe {@link SourcePanel}.
     *
     * @see SourcePanel#update
     * @param idPrec Identifiant de l'instruction précédente
     * @param idSuiv Identifiant de l'instruction courante
     */
    protected void updateSourcePanel(int idPrec, int idSuiv) {
        Instruction instructionPrec = null, instructionSuiv = null;
        if (0 <= idPrec && idPrec < listInstruction.size()) {
            instructionPrec = this.listInstruction.get(idPrec);
        }
        if (0 <= idSuiv && idSuiv < listInstruction.size()) {
            instructionSuiv = this.listInstruction.get(idSuiv);
        }

        this.sourcePanel.update(instructionPrec != null ? instructionPrec.getLigne() - 1 : -1,
                instructionPrec != null ? instructionPrec.getFichier() : null,
                instructionSuiv != null ? instructionSuiv.getLigne() - 1 : -1,
                instructionSuiv != null ? instructionSuiv.getFichier() : null);
    }

    /**
     * Signal l'activation d'un bouton, si ce boutton est le bouton Suivant
     * alors appelle l'affichage de l'instruction courante, sinon appelle
     * l'affichage de l'instruction précédente.
     *
     * @param e Objet d'évènement qui indique le bouton qui a été activé
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        Fenetre.labelErrorMessage.setText("");
        /* Si le boutton suivant est activé Boolean.compare renvoi 0*/
        switch (Boolean.compare(e.getSource().equals(this.buttonPrev), false)) {
            case 0: {
                /* Si l'identifiant est valide showInstruction renvoie vrai. */
                if (showInstruction(identifiant)) {
                    /* Si le boutton revenir est dessactivé, on l'active. */
                    if (!this.buttonPrev.isEnabled()) {
                        this.buttonPrev.setEnabled(true);
                    }
                    /* Mise à jour de la zone graphique du code source. */
                    this.updateSourcePanel(identifiant, ++identifiant);
                    /* Si on est arrivé à la dernière instruction alors on déssactive le boutton suivant. */
                    if (identifiant >= listInstruction.size()) {
                        this.buttonNext.setEnabled(false);
                        identifiant = listInstruction.size();
                    }
                } else {
                    this.buttonNext.setEnabled(false);
                }
                /* Mise à jour graphique globale*/
                componentResized(null);
                break;
            }
            case 1: {
                /* Si l'identifiant est valide retourArriere renvoie vrai. */
                if (retourArriere(identifiant - 1)) {
                    /* Si le boutton suivant est dessactivé, on l'active. */
                    if (!this.buttonNext.isEnabled()) {
                        this.buttonNext.setEnabled(true);
                    }
                    /* Mise à jour de la zone graphique du code source. */
                    this.updateSourcePanel(--identifiant - 1, identifiant);
                    /* Si on est arrivé à la première instruction alors on déssactive le boutton revenir. */
                    if (identifiant <= 0) {
                        this.buttonPrev.setEnabled(false);
                        identifiant = 0;
                    }
                }
                componentResized(null);
                break;
            }
        }
    }

    /**
     * Affiche une instruction
     *
     * @param id Identifiant de l'instruction a affiché
     * @return si l'identifiant existe renvoi vrai, sinon renvoi faux.
     */
    protected boolean showInstruction(int id) {
        if (!this.listInstruction.isEmpty()) {
            if (0 <= id && id < this.listInstruction.size()) {
                Instruction instruction = this.listInstruction.get(id);
                removeFleche(id - 1);
                hideStacklist(id - 1);
                switch (instruction.getTypeInstruction()) {
                    case eTypeAffectation:
                        /*
                         Si l'instruction est une affectation on effectue l'affectation et 
                         on change la couleur de son modèle graphique en rouge
                         */
                        if (((Affectation) instruction).affect()) {
                            instruction.produireComposant().setForeground(new Color(255, 51, 51));
                            instruction.produireComposant().setVisible(true);
                        } else {
                            return false;
                        }
                        break;
                    case eTypeMessage:
                        /* Si l'instruction est un message, celui-ci est recupéré et affiché */
                        System.out.println(((Message) instruction).getMessage());
                        labelErrorMessage.setText("Message : " + ((Message) instruction).getMessage());
                        break;
                    case eTypePointeur:
                        if (!(instruction.produireComposant() instanceof Composant)) {
                            instruction.produireComposant().setForeground(new Color(255, 51, 51));
                        }
                    case eTypeVariable:
                        /* Si cet instruction est une variable ayant une valeur
                         on change la couleur de son modèle graphique en rouge.
                         */
                        if (!"NOINIT".equals(((Variable) instruction).getValeur().toString())) {
                            instruction.produireComposant().setForeground(new Color(255, 51, 51));
                        }
                        break;
                }
                if (instruction.getTypeInstruction() != enumType.eTypeMessage) {
                    /* Si le modèle graphique de l'instruction n'est pas présente (visible on non) on y ajoute. */
                    if (!mainPanel.isAncestorOf(instruction.produireComposant())
                            && !declarationPanel.isAncestorOf(instruction.produireComposant())) {
                        if (enumType.eTypeStacklist == instruction.getTypeInstruction()) {
                            /* Si cet instruction est un eTypeStacklist il sera ajouté à la partie eTypeFonction. */
                            mainPanel.add(instruction.produireComposant(), BorderLayout.NORTH);
                        } else {
                            /* Sinon cet instruction est ajouté à la partie déclaration. */
                            declarationPanel.add(instruction.produireComposant());
                        }
                    }
                    instruction.produireComposant().setVisible(true);
                }

                return true;
            }
        }
        return false;
    }

    /**
     * Annule une operation d'affectation, efface l'instruction et appelle
     * l'affichage de l'instruction précédente via {@link #showInstruction(int)
     * }.
     *
     * @param id Identifiant de l'instruction à annuler
     * @return si l'identifiant existe renvoi vrai, sinon renvoi faux.
     * @see Affectation#desaffect()
     */
    protected boolean retourArriere(int id) {
        Instruction instruction;
        if (!this.listInstruction.isEmpty()) {
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                switch (instruction.getTypeInstruction()) {
                    case eTypeAffectation:
                        ((Affectation) instruction).desaffect(); /* Annulation d'une eTypeAffectation. */
                        /* Suppresion de flèche temporaire sur les variables copiées. */

                        removeFleche(id);
                        hideStacklist(id);
                        showInstruction(id - 1); /* Affichage de l'instruction précédente. */

                        break;
                    case eTypeMessage:
                        break;
                    default:
                        instruction.produireComposant().setEnabled(false);
                        instruction.produireComposant().setVisible(false);
                        instruction.produireComposant().setEnabled(true);
                        /*Annulation de l'affichage de l'instruction courante et affichage de l'instruction précédente. */
                        //instruction.produireComposant().setVisible(false);
                        showInstruction(id - 1);
                        break;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Appelle l'effacement l'affichage d'une flèche en pointillé générer par
     * une instruction affectation via la méthode
     * {@link Affectation#removeFlecheTemporaire()  removeFlecheTemporaire} de
     * la classe {@link Affectation}.
     *
     * @param id Identifiant de l'instruction
     */
    protected void removeFleche(int id) {
        Instruction instruction;
        if (!this.listInstruction.isEmpty()) {
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                if (instruction.getTypeInstruction() == enumType.eTypeAffectation) {
                    ((Affectation) instruction).removeFlecheTemporaire();
                    instruction.produireComposant().setForeground(Color.WHITE);
                }
            }
        }
    }

    /**
     * Efface une stacklist si l'instruction est un return
     *
     * @param id Identifiant de l'instruction
     */
    protected void hideStacklist(int id) {
        Instruction instruction;
        if (!this.listInstruction.isEmpty()) {
            if (0 <= id && id < this.listInstruction.size()) {
                instruction = this.listInstruction.get(id);
                switch (instruction.getTypeInstruction()) {
                    case eTypeArray:
                    case eTypeStructure:
                    case eTypePointeur:
                    case eTypeVariable:
                        if ("@return".equals(((Variable) instruction).getNom())) {
                            instruction.produireComposant().setVisible(false);
                        }
                        instruction.produireComposant().setForeground(Color.WHITE);
                        break;
                }
            }
        }
    }

}
