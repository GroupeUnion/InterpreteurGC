/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreteurgraphic;

import java.awt.Component;
import java.util.EventListener;
import xmlstructure.Instruction;
/**
 *
 * @author mahamat
 */
public class OperationClass {
    
    public enum enumFigure
    {
        composant, label, arrayfigure, fonctionfigure 
    }

    public interface OperationListener extends EventListener {

        public void componentEvent(boolean c);
    }

    public interface OperationAdapter{

        public abstract void addOperationListener(OperationClass.OperationListener operation);

        public abstract void setHaveMargin(boolean haveMargin);

        public abstract void setMargin(int top, int left, int bottom, int right);

        public abstract  enumFigure getTypeFigure();
        
        public abstract void removeReferer(Component toReferer);

        public abstract void setToReferer(Component toReferer);

        public abstract void addReferer(Component toReferer);

        public abstract void setVisibleEvent(Instruction source, boolean isVisible);
        
        public abstract void setDeplacable(boolean isDeplacable);
    }
    
}
