/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreteurgraphic;

import java.awt.Component;
import java.util.EventListener;
import xmlstructure.Instruction;

/**
 *
 * @author mahamat
 */
public class OperationClass {

    public enum enumFigure {

        composant, label, arrayfigure, fonctionfigure
    }

    public interface OperationListener extends EventListener {

        /**
         * Signal le changement d'une visibilité
         * @param c visibilité
         */
        public void setVisibility(boolean c);
    }

    public interface OperationAdapter {

        /**
         * Ajoute un abonné à la liste des abonnées qui recevront un signal en
         * cas de changement sur la visibilité.
         *
         * @param operation objet abonné
         */
        public abstract void addOperationListener(OperationClass.OperationListener operation);

        /**
         * Modifie l'élément indiquant si l'objet graphique possède une marge
         *
         * @param haveMargin marge active ou non
         */
        public abstract void setHaveMargin(boolean haveMargin);

        /**
         * Modifie la marge de l'objet graphique
         *
         * @param top taille de la marge en haut
         * @param left taille de la marge à gauche
         * @param bottom taille de la marge en bas
         * @param right taille de la marge à droite
         */
        public abstract void setMargin(int top, int left, int bottom, int right);

        /**
         * Renvoi le type de l'objet graphique
         *
         * @return type de l'objet graphique
         */
        public abstract enumFigure getTypeFigure();

        /**
         * Supprime une flèche d'un objet graphique vers une autre
         *
         * @param toReferer Objet graphique : source de la flèche
         */
        public abstract void removeReferer(Component toReferer);

        /**
         * Ajoute une flèche d'un objet graphique vers une autre et supprime
         * toutes les autres qui pointaient aux préalables vers cet autre.
         *
         * @param toReferer Objet graphique : source de la flèche
         */
        public abstract void setToReferer(Component toReferer);

        /**
         * Ajoute une flèche d'un objet graphique vers une autre
         *
         * @param toReferer Objet graphique : source de la flèche
         */
        public abstract void addReferer(Component toReferer);

        /**
         * Rend déplaçable ou non l'objet graphique et tous ses fils.
         *
         * @param isDeplacable Déplaçabilité
         */
        public abstract void setDeplacable(boolean isDeplacable);
    }

}
