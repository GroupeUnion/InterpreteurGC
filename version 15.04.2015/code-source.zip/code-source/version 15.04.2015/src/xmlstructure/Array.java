package xmlstructure;

import interpreteurgraphic.ArrayFigure;
import interpreteurgraphic.Composant;
import interpreteurgraphic.Label;
import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;
import xmlstructure.Variable.MemorySet;

/**
 *
 * @author mahamat
 */
public class Array extends Variable implements Serializable, MemorySet {

    protected Variable listCases[];
    private boolean isPointer;
    private int nbElement;
    private ArrayFigure arrayfigure;
    private final Composant composant;

    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, int count) {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        if (!this.isPointer) {
            this.nbElement = count;
            listCases = new Variable[nbElement];
            String typeCase = type.replaceAll("\\[\\]", "").trim();
            for (int i = 0; i < listCases.length; i++) {
                listCases[i] = new Variable(this.ident, typeCase, "[" + i + "]", "NOINIT", this.ligne, this.fichier);
            }
        }
        this.composant = new Composant(getType() + " " + nom);
    }

    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, List<Variable> listVariable) {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        this.nbElement = listVariable.size();
        this.listCases = new Variable[listVariable.size()];
        listVariable.toArray(this.listCases);
        this.composant = new Composant(getType() + " " + nom);
    }

    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, Structure modele, int count) throws IOException, ClassNotFoundException {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        this.nbElement = count;
        listCases = new Variable[nbElement];
        for (int i = 0; i < listCases.length; i++) {
            listCases[i] = modele.copie();
            listCases[i].setNom("[" + i + "]");
        }
        this.composant = new Composant(getType() + " " + nom);
    }

    @Override
    public Variable getVariable(String name, String parent) {
        if (isPointer && listCases == null) {
            return null;
        }
        for (Variable variable : listCases) {
            String newParentName = variable.getNomComplet(parent);
            if (newParentName.equals(name)) {
                return variable;
            } else if ((variable = variable.getVariable(name, newParentName)) != null) {
                return variable;
            }
        }
        return null;
    }

    @Override
    public StringBuilder getValeur() {
        return (listCases != null) ? listCases[0].getValeur() : new StringBuilder("NULL");
    }

    @Override
    public void setValeur(String valeur) {
        if (listCases != null) {
            listCases[0].setValeur(valeur);
        }
    }

    @Override
    public void set(Pointer p) {
    }

    @Override
    public void set(Array array) {
        isPointer = array.isPointer;
        arrayfigure = array.arrayfigure;
        listCases = array.listCases;
        updateComposant();
    }

    @Override
    public void set(Variable[] listVariable) {
        if (listCases == null) {
            listCases = listVariable;
        } else {
            if (listVariable != null) {
                if (listCases.length < listVariable.length) {
                    listCases = new Variable[listVariable.length];
                }
                System.arraycopy(listVariable, 0, listCases, 0, listVariable.length);
            } else {
                listCases = null;
            }
        }
        this.updateComposant();
    }

    /*pointeur identique*/
    @Override
    public void set(Variable variable) {
        listCases[0] = variable;
        listCases[0].setNom((isPointer) ? "" : "[0]");
    }

    @Override
    public void setPointer(boolean isPointer) {
        this.isPointer = isPointer;
    }

    public boolean isEmpty() {
        return listCases == null || listCases.length == 0;
    }

    /*clonage du tableau*/
    @Override
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();   
        ((Array)copied).arrayfigure = arrayfigure;
        out.close();
        bos.close();
        bis.close();
        in.close();
        return copied;
    }

    @Override
    public Component produireComposant() {
        if (arrayfigure == null) {
            arrayfigure = new ArrayFigure();
            if (listCases != null && !isPointer) {
                for (Variable variable : listCases) {
                    Component component = variable.produireComposant();
                    if (component instanceof Label) {
                        ((Label) component).setHaveMargin(false);
                    }
                    component.setName(variable.getNom());
                    component.setVisible(true);
                    arrayfigure.addCase(component);
                }
            }
            if (!isPointer) {
                arrayfigure.addPointer(composant);
            }
            arrayfigure.setVisible(false);
        }
        return arrayfigure;
    }

    public void updateComposant() {
        if (arrayfigure != null) {
            arrayfigure.removeAllCases();
            if (!isPointer && listCases != null && arrayfigure.isDeplacable()) {
                for (int i = 0; i < listCases.length; i++) {
                    Variable variable = listCases[i];
                    Component component = variable.produireComposant();
                    if (component instanceof Label) {
                        ((Label) component).setHaveMargin(false);
                    }
                    component.setVisible(true);
                    component.setName("[" + i + "]");
                    arrayfigure.addCase(component);
                }
            }
        }
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.array;
    }

}
