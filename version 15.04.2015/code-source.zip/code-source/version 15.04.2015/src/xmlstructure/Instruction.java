package xmlstructure;

import java.awt.Component;
import java.io.Serializable;

/**
 *
 * @author mahamat
 */
public abstract class Instruction implements Serializable {

    /**
     * Identifiant d'une instruction
     */
    protected String ident;
    /**
     * Ligne source d'une instruction
     */
    protected String ligne;
    /**
     * Fichier source d'une instruction
     */
    protected String fichier;

    /**
     * Enumration des balises et type de variables.
     */
    public enum enumType {

        eTypeNull("null"),
        eTypeParam("param"),
        eTypeArray("array"),
        eTypeUnion("union"),
        eTypeVariable("var"),
        eTypeReturn("return"),
        eTypeMessage("message"),
        eTypeStructure("struct"),
        eTypePointeur("pointer"),
        eTypePrimitif("primitif"),
        eTypeFonction("function"),
        eTypeAffectation("affect"),
        eTypeStacklist("stacklist"),
        eTypeDessalloc("dessalloc");

        private final String type;

        private enumType(String type) {
            this.type = type;
        }

        public static enumType getTypeOf(String text) {
            if (text != null) {
                for (enumType b : enumType.values()) {
                    if (text.equalsIgnoreCase(b.type)) {
                        return b;
                    }
                }
            }
            return eTypeNull;
        }
    }

    /**
     * Initialise l'identifiant, ligne, et le fichier source d'une instruction
     * @param ident Identifiant d'une instruction
     * @param ligne Ligne d'une instruction
     * @param fichier Chemin d'accès d'une instruction
     */
    public Instruction(String ident, String ligne, String fichier) {
        this.ident = ident;
        this.ligne = ligne;
        this.fichier = fichier;
    }

    /**
     * Renvoi l'identifiant d'une instruction convertie en entier, si elle existe,
     * sinon renvoi -1.
     * @return identifiant d'une instruction
     */
    public int getIdent() {
        return (ident == null) ? -1 : Integer.parseInt(ident);
    }

    /**
     * Renvoi la ligne d'une instruction convertie en entier, si elle existe,
     * sinon renvoi -1.
     * @return Ligne d'une instruction
     */
    public int getLigne() {
        return (ident == null) ? -1 : Integer.parseInt(ligne);
    }

    /**
     * Renvoie le fichier source d'une instruction
     * @return Chemin d'accès d'une instruction
     */
    public String getFichier() {
        return fichier;
    }

    /**
     * Modifie l'identifiant d'une instruction
     * @param ident Nouvel identifiant d'une instruction
     */
    public void setIdent(String ident) {
        this.ident = ident;
    }

    /**
     * Modifie la ligne d'une instruction
     * @param ligne Nouvelle ligne d'une instruction
     */
    public void setLigne(String ligne) {
        this.ligne = ligne;
    }

    /**
     * Modifie le fichier source d'une instruction
     * @param fichier Nouveau chemin d'accès
     */
    public void setFichier(String fichier) {
        this.fichier = fichier;
    }

    /**
     * Crée ou renvoi un objet graphique à partir des informations de l'instruction.
     * @return Objet graphique de l'instruction
     */
    public abstract Component produireComposant();

    /**
     * Renvoie le type de l'instruction
     * @return Type de l'instruction
     */
    public abstract enumType getTypeInstruction();

}
