package xmlstructure;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import xmlstructure.Instruction.enumType;

/**
 * CLass de chargement et de traitement xml
 *
 * @author mahamat
 */
public class ReadXml {

    /**
     * En cas de chargement d'un fichier xml, cette les chemins d'acces vers les
     * codes sources
     */
    private String[] fileSources;
    /**
     * Liste des variables déclarées
     */
    private final Map<Integer, Instruction> hashDeclaration;
    /**
     * Listes des instructions complètes (déclarations + autres)
     */
    private final Map<Integer, Instruction> hashExecution;

    /**
     * Constructeur de la class de gestion xml
     */
    public ReadXml() {
        hashDeclaration = new HashMap<Integer, Instruction>();
        hashExecution = new HashMap<Integer, Instruction>();
    }

    /**
     * Chargement d'un fichier xml par le chemin d'accès
     *
     * @param file Chemin d'accès d'un fichier xml
     */
    public void chargement_xml(String file) {
        try {
            SAXBuilder sxb = new SAXBuilder();
            Document document = sxb.build(new File(file));
            Element racine = document.getRootElement();
            extraire_instruction(racine.getChild("declaration"), true);
            extraire_instruction(racine.getChild("execution"), true);
            extraire_file_source(racine.getChild("file"));
            hashDeclaration.clear();
        } catch (JDOMException ex) {
            System.out.println("" + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("" + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("" + ex.getMessage());
        }
    }

    /**
     * Chargement xml par un tampon mémoire
     *
     * @param input tampon mémoire
     */
    public void chargement_xml(BufferedReader input) {
        try {
            SAXBuilder sxb = new SAXBuilder();
            Document document = sxb.build(input);
            Element racine = document.getRootElement();
            extraire_instruction(racine.getChild("declaration"), true);
            extraire_instruction(racine.getChild("execution"), true);
            extraire_file_source(racine.getChild("file"));
            hashDeclaration.clear();
        } catch (JDOMException ex) {
            System.out.println("" + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("" + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("" + ex.getMessage());
        }
    }

    /**
     * Recherche une variable déclarée via son id
     *
     * @param id Identifiant de la variable
     * @return Variable déclarée
     */
    protected Variable getVariableHashMaById(String id) {
        Variable variable;
        variable = (Variable) hashDeclaration.get(Integer.parseInt(id));
        return variable;
    }

    /**
     * Recherche une variable déclarée via son type ou son nom
     *
     * @param type Type de la variable
     * @param name Nom de la variable
     * @return Variable déclarée
     */
    protected Variable getVariableHashMapByAny(String type, String name) {
        Variable variable;
        for (Map.Entry<Integer, Instruction> entry : hashDeclaration.entrySet()) {
            if (entry.getValue() instanceof Variable) {
                variable = (Variable) entry.getValue();
                if (variable.getType().equals(type) && variable.getNom().equals(name)) {
                    return variable;
                }
            }
        }
        return null;
    }

    /**
     * Recupère les informations d'une instruction affectation
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @return Affectation récupéré
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    private Affectation extraire_affectation(Element e) throws IOException, ClassNotFoundException {
        Affectation affectation;
        List<Variable> listVariable;
        Variable source = null, destination;
        //Si l'affectation possède une source on la récupère, elle permettra de tracer une flèche de la source vers la variable affectée.
        if (e.getAttributeValue("nsrc") != null) {
            source = getVariableHashMaById(e.getAttributeValue("id_src"));
        }
        //Récupération de la variable affectée
        destination = getVariableHashMaById(e.getAttributeValue("id_dest"));
        /*Affectation d'une variable primitive*/
        if (e.getAttributeValue("typeid").equals("primitif") || e.getContentSize() == 0) {
            /*Récuparation de la valeur du code ascii pour les caractères*/
            String ascii = e.getAttributeValue("ascii");
            ascii = ascii == null ? "" : "@" + ascii;
            affectation = new Affectation(e.getAttributeValue("id"), e.getAttributeValue("line"),
                    e.getAttributeValue("file"), source, destination, e.getAttributeValue("typeid"),
                    e.getAttributeValue("value") + ascii, e.getAttributeValue("ndest"), e.getAttributeValue("nsrc"));
        } else {
            /*Affectation de variable complexe (eTypeArray, pointeur, ...)*/
            listVariable = getListValue(e);/*récupération de la liste de var s'il n'y a pas de source*/

            affectation = new Affectation(e.getAttributeValue("id"), e.getAttributeValue("line"),
                    e.getAttributeValue("file"), source, destination, e.getAttributeValue("typeid"), listVariable,
                    e.getAttributeValue("ndest"), e.getAttributeValue("nsrc"));
        }

        return affectation;
    }

    /**
     * Recupère les instructions d'un bloc d'instruction
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @return Bloc récupéré contenant une liste d'instruction
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    private Stacklist extraire_stacklist(Element e) throws IOException, ClassNotFoundException {
        Stacklist bloc;
        Instruction instruction;
        Variable variable = null;
        List<Element> noeudMembre;
        List<Variable> listVariable = null;
        List<Instruction> listeInstruction = new ArrayList<Instruction>();
        switch (enumType.getTypeOf(e.getAttributeValue("typeid"))) {
            case eTypeFonction:
                listVariable = new ArrayList<Variable>();
                if (e.getChild("return") != null) {
                    variable = (Variable) extraire_instruction(e.getChild("return"), true);
                    e.removeChild("return");
                }
                if ((noeudMembre = e.getChildren("param")) != null) {
                    for (Element membre : noeudMembre) {
                        instruction = (Instruction) extraire_instruction(membre, true);
                        listVariable.add((Variable) instruction);
                    }
                    e.removeChildren("param");
                }
            default:
                if (e.getChild("return") != null && variable == null) {
                    variable = (Variable) extraire_instruction(e.getChild("return"), true);
                    e.removeChild("return");
                }
                if ((noeudMembre = e.getChildren()) != null) {
                    for (Element membre : noeudMembre) {
                        instruction = (Instruction) extraire_instruction(membre, true);
                        listeInstruction.add(instruction);
                    }
                }
                break;
        }
        bloc = new Stacklist(e.getAttributeValue("id"), variable, listVariable, listeInstruction, e.getAttributeValue("type"), e.getAttributeValue("typeid"),
                e.getAttributeValue("line"), e.getAttributeValue("file"), e.getAttributeValue("name"));
        return bloc;
    }

    /**
     * Récupère les informations d'une structure
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @return Structure récupéré
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    private Variable extraire_structure(Element e) throws IOException, ClassNotFoundException {
        Structure structModele;
        List<Element> noeudMembre;
        if ((structModele = (Structure) getVariableHashMapByAny(e.getAttributeValue("type"), "")) == null) {
            structModele = new Structure(e.getAttributeValue("id"), e.getAttributeValue("type"),
                    e.getAttributeValue("name"), e.getAttributeValue("line"), e.getAttributeValue("file"));
            noeudMembre = e.getChildren();
            for (Element membre : noeudMembre) {
                structModele.addMembre((Variable) extraire_instruction(membre, false));
            }
        } else {
            structModele = (Structure) structModele.copie();
            structModele.setNom(e.getAttributeValue("name"));
            structModele.setIdent(e.getAttributeValue("id"));
            structModele.setLigne(e.getAttributeValue("line"));
            noeudMembre = e.getChildren();
            if (!noeudMembre.isEmpty()) {
                structModele.clearMembre();
            }
            for (Element membre : noeudMembre) {
                structModele.addMembre((Variable) extraire_instruction(membre, false));
            }
        }
        return structModele;
    }

    /**
     * Récupère les informations d'un tableau ou d'un pointeur
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @param isPointer Indique s'il s'agit d'un pointeur ou d'un tableau
     * @return Instruction récupéré
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    private Variable extraire_array(Element e, boolean isPointer) throws IOException, ClassNotFoundException {

        Array array;
        Structure structModele;
        List<Variable> listVariable;
        String type = e.getAttributeValue("type");
        if (e.getChild("var") != null) {
            listVariable = getListValue(e);
            array = new Array(e.getAttributeValue("id"), e.getAttributeValue("type"),
                    e.getAttributeValue("name"), isPointer, e.getAttributeValue("line"),
                    e.getAttributeValue("file"), listVariable);
        } else if (!isPointer && (type.contains("struct")/*tableau de structure*/ || type.contains("union"))) {
            structModele = (Structure) getVariableHashMapByAny(type.replaceAll("\\[\\]", "").trim(), "");
            if (structModele != null) {
                structModele = (Structure) structModele.copie();
                structModele.setNom(e.getAttributeValue("name"));
            }
            array = new Array(e.getAttributeValue("id"), e.getAttributeValue("type"),
                    e.getAttributeValue("name"), isPointer, e.getAttributeValue("line"),
                    e.getAttributeValue("file"), structModele, Integer.parseInt(e.getAttributeValue("count")));
        } else {
            String cout = e.getAttributeValue("count");
            array = new Array(e.getAttributeValue("id"), e.getAttributeValue("type"),
                    e.getAttributeValue("name"), isPointer, e.getAttributeValue("line"),
                    e.getAttributeValue("file"), Integer.parseInt(cout == null ? "0" : cout));
        }
        return (isPointer) ? new Pointer(array) : array;
    }

    /**
     * Récupère les informations d'une variable déclarée
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @return Variable déclarée dans un fichier C
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    private Variable extraire_variable(Element e) throws IOException, ClassNotFoundException {
        Variable variable = null;
        switch (enumType.getTypeOf(e.getAttributeValue("typeid"))) {
            case eTypePrimitif:
                String ascii = e.getAttributeValue("ascii");
                ascii = ascii == null ? "" : "@" + ascii;
                variable = new Variable(e.getAttributeValue("id"), e.getAttributeValue("type"),
                        e.getAttributeValue("name"), e.getAttributeValue("value") + ascii,
                        e.getAttributeValue("line"), e.getAttributeValue("file"));
                break;
            case eTypeUnion:
            case eTypeStructure:
                variable = extraire_structure(e);
                break;
            case eTypePointeur:
                variable = extraire_array(e, true);
                break;
            case eTypeArray:
                variable = extraire_array(e, false);
                break;
        }
        return variable;
    }

    /**
     * Parcours récursivement une hiérachie de balise et récupère selon les
     * caractéristiques les informations sous forme d'instruction
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @param sauvegarder Indique si l'instruction récupéré doit être enregistré
     * et ou renvoyé
     * @return Instruction récupéré
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    protected Instruction extraire_instruction(Element e, boolean sauvegarder) throws IOException, ClassNotFoundException {
        Stacklist bloc;
        Affectation affectation;
        Instruction instruction;
        Variable source, variable;
        switch (enumType.getTypeOf(e.getName())) {
            case eTypeAffectation:
                affectation = extraire_affectation(e);
                hashExecution.put(affectation.getIdent(), affectation);
                return affectation;
            case eTypeStacklist:
                bloc = extraire_stacklist(e);
                hashExecution.put(bloc.getIdent(), bloc);
                return bloc;
            case eTypeReturn:
            case eTypeParam:
            case eTypeVariable: {
                variable = extraire_variable(e);
                //Si la variable contient une valeur provenant d'une autre on récupère la variable source pour le tracé de flèche
                if (e.getAttributeValue("nsrc") != null) {
                    source = getVariableHashMaById(e.getAttributeValue("id_src"));
                    affectation = new Affectation(e.getAttributeValue("id"), e.getAttributeValue("line"),
                            e.getAttributeValue("file"), source, variable, e.getAttributeValue("typeid"), variable.getValeur().toString(),
                            variable.getNom(), e.getAttributeValue("nsrc"));
                    /*Si cette variable n'est pas un membre d'une structure ou d'un tableau, alors elle doit être sauvegardé,
                     en règle générale les balises variables n'ayant pas d'identifiant sont membres de structure de données complexes*/
                    if (sauvegarder) {
                        hashDeclaration.put(variable.getIdent(), variable);
                        hashExecution.put(variable.getIdent(), affectation);
                    }
                } else if (sauvegarder) {
                    hashDeclaration.put(variable.getIdent(), variable);
                    hashExecution.put(variable.getIdent(), variable);
                }
                return variable;
            }
            case eTypeMessage:
                instruction = new Message(e.getAttributeValue("id"), e.getAttributeValue("line"),
                        e.getAttributeValue("file"), e.getContent(0).getValue());
                hashExecution.put(instruction.getIdent(), instruction);
                return instruction;
        }
        if (sauvegarder) {
            List<Element> list_element = e.getChildren();
            for (Element element : list_element) {
                extraire_instruction(element, sauvegarder);
            }
        }
        return null;
    }

    /**
     * Récupère une liste de variable
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @return Liste de variable
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    protected List<Variable> getListValue(Element e)
            throws IOException, ClassNotFoundException {
        List<Element> noeudMembre = e.getChildren();
        List<Variable> variable = Arrays.asList(new Variable[noeudMembre.size()]);
        for (int i = 0; i < noeudMembre.size(); i++) {
            Element element = noeudMembre.get(i);
            variable.set(i, (Variable) extraire_instruction(element, false));
        }
        return variable;
    }

    /**
     * Récupère les chemins d'accès des fichiers sources
     *
     * @param e Element xml représentant une balise et contenant les
     * informations à récupérer
     * @return Tableau des chemins d'accès des fichiers sources.
     */
    private String[] extraire_file_source(Element e) {
        List<Element> sourceList = e.getChildren("source");
        fileSources = new String[sourceList.size()];
        for (int i = 0; i < sourceList.size(); i++) {
            fileSources[i] = sourceList.get(i).getAttributeValue("href");
        }
        return fileSources;
    }

    /**
     * Renvoie la liste des instructions
     *
     * @return Liste des instructions
     */
    public Map<Integer, Instruction> getHashExecution() {
        return hashExecution;
    }

    /**
     * Renvoie la liste des chemins d'accès des fichiers de codes sources.
     *
     * @return Tableau des chemins d'accès des fichiers sources.
     */
    public String[] getFileSources() {
        return fileSources;
    }

}
