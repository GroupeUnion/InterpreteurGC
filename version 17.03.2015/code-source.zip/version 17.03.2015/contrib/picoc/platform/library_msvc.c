#include "../interpreter.h"

void PlatformLibraryInit()
{
}
