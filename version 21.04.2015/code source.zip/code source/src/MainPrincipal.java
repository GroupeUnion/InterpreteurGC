
import interpreteurgraphic.Fenetre;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import xmlstructure.ReadXml;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class MainPrincipal {

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Veuillez passez en argument les fichiers C suivi potentiellement des args liées aux fichiers C "
                    + "ou un fichier xml à afficher");
            return;
        }
        ReadXml readxml = new ReadXml();
        try {
            if (args[0].endsWith(".c")) {
                Path picoc = Paths.get("picoc");
                Path picocExe = Paths.get("picoc.exe");
                if (!Files.isExecutable(picoc) && !Files.isExecutable(picocExe)) {
                    System.out.println("Erreur l'executable picoc est introuvable");
                    System.out.print("Solution 1: si l'executable picoc existe");
                    System.out.println(" deplacer l'executable picoc dans le meme repertoire que ce programme");
                    System.out.print("Solution 2: si l'executable picoc n'existe pas");
                    System.out.println(" compiler via l'utilitaire make le code source de picoc");
                    System.exit(-2);
                }
                String programme[] = new String[args.length + 1];
                programme[0] = "./picoc";
                System.arraycopy(args, 0, programme, 1, args.length);
                ProcessBuilder pb = new ProcessBuilder(programme);
                pb.redirectErrorStream(true);
                Process process = pb.start();
                Thread Thread = redirectStdin(process.getOutputStream(), new Scanner(System.in));
                //process.redirectOutput(new FileOutputStream(new File(outfile));
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                System.out.println("Chargement ... Patientez");
                readxml.chargement_xml(reader);
                int exitVal = process.waitFor();
                if (exitVal != 0) {
                    process = pb.start();
                    reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (!line.contains("<") && !line.contains(">")) {
                            System.out.println(line);
                        }
                    }
                    exitVal = process.waitFor();
                    System.out.println("Code d'erreur " + exitVal);
                    System.exit(-1);
                }
                Thread.interrupt();

            } else {
                readxml.chargement_xml(args[0]);
            }            
            System.out.println("Chargement réussi !!! ");
            Fenetre fenetre = new Fenetre("Interpreteur graphique pour le langage C", 1040, 580, readxml.getHashExecution());
            fenetre.chargement(readxml.getFileSources());
            fenetre.revalidate();

        } catch (IOException e) {
            System.out.println(e.toString());
        } catch (InterruptedException e) {
            System.out.println(e.toString());
        }

    }

    /**
     * Redirige les entrées claviers vers le programme picoc démarré
     *
     * @param writer Flux d'entrée d'un programme picoc
     * @param scan Interface permettant la lecture des entrées clavier.
     * @return Référence sur la tâche en parallèle
     */
    public static Thread redirectStdin(final OutputStream writer, final Scanner scan) {
        Thread T = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String input;
                    while (true) {
                        input = scan.nextLine() + "\n";
                        writer.write(input.getBytes());
                        writer.flush();
                    }
                } catch (IOException e) {
                    System.out.println("" + e.getMessage());
                }
            }
        });
        T.start();
        return T;
    }
}
