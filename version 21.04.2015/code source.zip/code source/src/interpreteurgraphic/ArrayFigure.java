/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreteurgraphic;

import interpreteurgraphic.OperationClass.OperationAdapter;
import interpreteurgraphic.OperationClass.OperationListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.EventListenerList;

/**
 *
 * @author mahamat Objet graphique représentant une zone mémoire et les
 * pointeurs sur cette zone
 */
public class ArrayFigure extends JPanel implements OperationAdapter {

    private final EventListenerList listeners;
    private final List<Component> listCases;
    private final JPanel listePointer; /* Objet graphique contenant les pointeurs qui pointent sur la zone mémoire*/

    private final Composant array; /* Objet graphique représentant la zone mémoire*/

    private boolean isDeplacable; /*Indique si l'objet graphique est déplaçable c'est à dire peut être ajouté 
     à un autre objet graphique que son premier parent.*/


    public ArrayFigure() {
        this.listeners = new EventListenerList();
        this.listCases = new ArrayList<Component>();
        this.setLayout(new BorderLayout());
        this.setOpaque(false);
        this.listePointer = new JPanel();
        this.array = new Composant("-");

        this.listePointer.setBackground(Color.red);
        this.listePointer.setLayout(new FlowLayout(FlowLayout.LEFT));
        this.listePointer.setOpaque(false);

        this.add(listePointer, BorderLayout.NORTH);
        this.add(array, BorderLayout.CENTER);
        this.listePointer.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        this.isDeplacable = true;
        this.listePointer.setVisible(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); //To change body of generated methods, choose Tools | Templates.
        /*Si l'objet graphique représentant la zone mémoire est vide alors il l'a rend invisible*/
        if (array.getComponentCount() == 0) {
            array.setMargin(0, 0, 0, 0);
            array.setVisible(false);
        }
    }

    /**
     *
     * Modifie la couleur de police de l'objet graphique et de tous ses fils.
     *
     * @param fg nouvelle couleur de la police
     */
    @Override
    public void setForeground(Color fg) {
        super.setForeground(fg); //To change body of generated methods, choose Tools | Templates.
        if (this.listePointer != null) {
            if (array.getComponentCount() != 0) {
                for (Component c : this.listePointer.getComponents()) {
                    c.setForeground(fg);
                }
                array.setForeground(fg);
            }
        }
    }

    /**
     * Ajoute si possible un objet graphique représentant un pointeur.
     *
     * @param c Objet graphique
     */
    public void addPointer(Composant c) {
        /*Si le pointeur est un objet graphique déplaçable, il est ajouté au conteneur de pointeurs.*/
        if (c.isDeplacable() && canMove(c)) {
            listePointer.add(c);
        }
        /*Appelle le tracé de la flèche du pointeur vers la zone mémoire pointé.*/
        this.addReferer(c);        
    }

    /**
     * Recherche un objet graphique représentant un pointeur
     *
     * @param c Objet graphique
     * @return Renvoi l'objet graphique représentant un pointeur.
     */
    private Component getPointer(Component c) {
        if (c instanceof ArrayFigure) {
            return getPointer(((ArrayFigure) c).getPointer());
        }
        return c;
    }

    /**
     * Renvoi le premier pointeur de la liste des pointeurs.
     *
     * @return Objet graphique représentant un pointeur.
     */
    public Component getPointer() {
        return getPointer(this.listePointer.getComponent(0));
    }

    /**
     * Ajoute une case à la zone mémoire.
     *
     * @param c Objet graphique représentant une case d'un tableau.
     */
    public void addCase(Component c) {
        array.add(c);
        /*
         Si l'objet graphique représentant la zone mémoire était vide 
         alors on ajoute des flèches s'il existe des pointeurs pointant vers elle
         et on affiche l'objet.
         */
        if (array.getComponentCount() == 1) {
            for (Component cs : listCases) {
                this.addReferer(cs);
            }
            array.setMargin(0, 0, 0, 0);
            array.setVisible(true);
        }
    }
    
    /**
     * 
     * @param c Objet graphique représentant une case d'un tableau
     */
    public void addToList(Component c)
    {
        this.listCases.add(c);        
    }

    /**
     * Supprime le contenu de l'objet graphique représentant une zone mémoire.
     */
    public void removeAllCases() {
        array.removeAll();
        this.listCases.clear();
    }

    /**
     * Appelle l'effacement de la flèche d'un pointeur c à une zone mémoire
     *
     * @param c Objet graphique représentant un pointeur.
     */
    public void removePointer(Component c) {
        this.removeReferer(c);
    }

    /**
     * Ajoute un abonné à la liste des abonnées en cas de changement sur la
     * visibilité.
     *
     * @param operation objet abonné
     */
    @Override
    public void addOperationListener(OperationClass.OperationListener operation) {
        listeners.add(OperationClass.OperationListener.class, operation);
    }

    /**
     * Modifie l'élément indiquant si les cases de la zone mémoire ont une marge
     *
     * @param haveMargin indique l'activation ou non des marges
     */
    @Override
    public void setHaveMargin(boolean haveMargin) {
        array.setHaveMargin(haveMargin);
    }

    /**
     * Modifie la marge des cases de la zone mémoire
     *
     * @param top taille de la marge en haut
     * @param left taille de la marge à gauche
     * @param bottom taille de la marge en bas
     * @param right taille de la marge à droite
     */
    @Override
    public void setMargin(int top, int left, int bottom, int right) {
        array.setMargin(top, left, bottom, right);
    }

    /**
     * Supprime une flèche d'un pointeur vers la zone mémoire
     *
     * @param toReferer Objet graphique : source de la flèche
     */
    @Override
    public void removeReferer(Component toReferer) {
        if (!this.listCases.isEmpty()) {
            Fenetre.flechePanel.removeFleche(getPointer(listCases.get(0)), toReferer);
        }
    }

    /**
     * Ajoute une flèche d'un pointeur vers la zone mémoire et supprime toutes
     * les autres.
     *
     * @param toReferer Objet graphique : source de la flèche
     */
    @Override
    public void setToReferer(Component toReferer) {
        if (!this.listCases.isEmpty()) {
            Fenetre.flechePanel.removeFlecheTo(getPointer(listCases.get(0)));
            Fenetre.flechePanel.addFleche(toReferer, getPointer(listCases.get(0)));
            Fenetre.flechePanel.repaint();
        }
    }

    /**
     * Ajoute une flèche d'un pointeur vers la zone mémoire.
     *
     * @param toReferer Objet graphique : source de la flèche
     */
    @Override
    public void addReferer(Component toReferer) {
        if (!this.listCases.isEmpty()) {
            Fenetre.flechePanel.addFleche(toReferer, getPointer(listCases.get(0)));
            Fenetre.flechePanel.repaint();
        }
    }

    /**
     * Renvoi le type de l'objet graphique
     *
     * @return type de l'objet graphique
     */
    @Override
    public OperationClass.enumFigure getTypeFigure() {
        return OperationClass.enumFigure.arrayfigure;
    }

    @Override
    public Rectangle getBounds() {
        return array.getBounds();
    }

    /**
     * Modifie la visibilité d'un objet et signal cette modification à tous les
     * objets graphiques abonnés.
     *
     * @param aFlag visibilité
     */
    @Override
    public void setVisible(boolean aFlag) {
        super.setVisible(aFlag); //To change body of generated methods, choose Tools | Templates.
        if (listeners.getListenerCount() != 0 && isEnabled()) {
            OperationListener abonnees[] = listeners.getListeners(OperationListener.class);
            for (OperationClass.OperationListener op : abonnees) {
                op.setVisibility(aFlag);
            }
        }
    }

    /**
     * Rend déplaçable ou non l'objet graphique et tous ses fils.
     *
     * @param isDeplacable Déplaçabilité
     */
    @Override
    public void setDeplacable(boolean isDeplacable) {
        this.isDeplacable = isDeplacable;
        array.setDeplacable(isDeplacable);
        for (Component cmpt : listePointer.getComponents()) {
            ((OperationAdapter) cmpt).setDeplacable(isDeplacable);
        }
    }

    /**
     * Indique si l'objet graphique est déplaçable
     *
     * @return déplaçabilité
     */
    public boolean isDeplacable() {
        return this.isDeplacable;
    }

    /**
     * Verifie si la condition de déplacement est respecté, soit pas de
     * déplacement d'objet graphique entre la zone déclaration et la zone
     * exécution.
     *
     * @param c Objet graphique à déplacer.
     * @return déplacement possible ou non
     */
    private boolean canMove(Component c) {
        Component ancestor1 = SwingUtilities.getAncestorNamed("###declaration###", c);
        Component ancestor2 = SwingUtilities.getAncestorNamed("###declaration###", this);
        Component ancestor3 = SwingUtilities.getAncestorNamed("###execution###", c);
        Component ancestor4 = SwingUtilities.getAncestorNamed("###execution###", this);
        return ((ancestor1 == ancestor2 && ancestor1 != null)
                || (ancestor1 == null && ancestor3 == null))
                || (ancestor3 == ancestor4);
    }

}
