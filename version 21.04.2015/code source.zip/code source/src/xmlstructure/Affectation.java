package xmlstructure;

import interpreteurgraphic.Fenetre;
import interpreteurgraphic.OperationClass.OperationAdapter;
import java.awt.Color;
import java.awt.Component;
import java.io.IOException;
import java.util.List;
import xmlstructure.Variable.MemorySet;

/**
 * Objet contenant les informations d'une affectation
 *
 * @author mahamat
 */
public class Affectation extends Instruction {

    /**
     * Variable source d'une affectation
     */
    private Variable source;

    /**
     * Variable destination d'une affectation
     */
    private Variable destination;

    /**
     * Variable de sauvegarde de la variable de destination permettant d'annuler
     * une affectation
     */
    private Variable sauvegarde;

    /**
     * Valeur de l'affectation pour une affectation sur une variable primitive.
     */
    private final String value;

    /**
     * Type de variable (primitif, array, pointeur, sttructure)
     */
    private final String typeid;
    /**
     * Nom complet de la variable destination. ex : a[0] ou a.membre1
     */
    private final String nameDest;

    /**
     * Nom complet de la variable source. ex : b[0] ou b.membre1
     */
    private final String nameSrc;

    /**
     * Liste de variable pour une affectation sur un pointeur et un tableau.
     */
    private final Variable[] listValues;
    
    /**
     * Indique si l'objet graphique est visible ou non
     */
    private boolean visibleComponent;

    /**
     * Contructeur de l'objet
     *
     * @param ident Identifiant de l'instruction
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param source Variable source de l'affectation
     * @param destination Variable destionation de l'affectation
     * @param typeid Type de la variable de destionation
     * @param value Valeur de l'affectation pour le type primitif
     * @param nameDest Nom complet de la variable de destination ex: a, a[0] ou
     * a.membre1
     * @param nameSrc Nom complet de la variable source ex: a, a[0] ou a.membre1
     */
    public Affectation(String ident, String ligne, String fichier,
            Variable source, Variable destination, String typeid, String value,
            String nameDest, String nameSrc) {
        super(ident, ligne, fichier);
        this.source = source;
        this.value = value;
        this.typeid = typeid;
        this.listValues = null;
        this.nameSrc = nameSrc;
        this.nameDest = nameDest;
        this.destination = destination;
    }

    /**
     *
     * @param ident Identifiant de l'instruction
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param source Variable source de l'affectation
     * @param destination Variable destionation de l'affectation
     * @param typeid Type de la variable de destionation
     * @param listValues Liste des valeurs affectées pour un tableau ou un
     * pointeur
     * @param nameDest Nom complet de la variable de destination ex: a, a[0] ou
     * a.membre1
     * @param nameSrc Nom complet de la variable source ex: a, a[0] ou a.membre1
     */
    public Affectation(String ident, String ligne, String fichier,
            Variable source, Variable destination, String typeid, List<Variable> listValues,
            String nameDest, String nameSrc) {
        super(ident, ligne, fichier);
        this.source = source;
        this.destination = destination;
        this.value = null;
        if (!listValues.isEmpty()) {
            this.listValues = new Variable[listValues.size()];
            listValues.toArray(this.listValues);
        } else {
            this.listValues = null;
        }
        this.typeid = typeid;
        this.nameDest = nameDest;
        this.nameSrc = nameSrc;
    }

    /**
     * Renvoi la valeur à affecter
     *
     * @return valeur de l'affectation sur variable primitif
     */
    public String getValue() {
        return value;
    }

    /**
     * Affecte une valeur ou une liste de valeur à une variable
     *
     * @return Indique si l'affectation a réussi
     */
    public boolean affect() {
        try {
            Variable variableDest = destination; /* sauvegarde la référence de la variable de destination*/

            Variable variableSource = source;
            destination = destination.getVariable(this.nameDest); /*recherche dans la variable de destination, la destination intern de l'affectation*/
            if (source != null ) {
                /*recherche dans la variable source, la source intern de l'affectation*/
                source = source.getVariable(this.nameSrc);
            }
            if (sauvegarde == null) {
                /*sauvegarde une copie de la variable de destination*/
                sauvegarde = destination.copie();
                visibleComponent = destination.produireComposant().isVisible();
            }
            /*affectation selon le type et la prevenance de ou des valeurs.*/
            switch (enumType.getTypeOf(typeid)) {
                case eTypePrimitif:
                    /*Si la valeur affecté est l'étiquette NOINIT alors la source n'a pas été initialisé*/
                    if ("NOINIT".equals(value)) {
                        Fenetre.labelErrorMessage.setText("Erreur ligne " + source.getLigne() + " : "
                                + source.getType() + " " + source.getNom() + " n'a pas été initialisé > " + source.getFichier());
                        destination = variableDest;
                        source = variableSource;
                        return false;
                    }
                    destination.setValeur(value);
                    if (source != null) {
                        ((OperationAdapter) destination.produireComposant()).setToReferer(source.produireComposant());
                    }
                    break;
                case eTypeArray:
                case eTypePointeur:
                    if (destination instanceof Pointer || destination instanceof Array) {
                        MemorySet pointer = (MemorySet) destination;
                        if (source == null) {
                            pointer.setByList(listValues);
                            destination.produireComposant();
                        } else if (source instanceof Array) {
                            pointer.setByArray((Array) source);
                        } else if (source instanceof Pointer) {
                            /*Si le pointer source n'a pas été initialisé*/
                            if (((MemorySet) source).isEmpty()) {
                                Fenetre.labelErrorMessage.setText("Erreur ligne " + source.getLigne() + " : "
                                        + source.getType() + " " + source.getNom() + " n'a pas été initialisé > " + source.getFichier());
                                destination = variableDest;
                                source = variableSource;
                                return false;
                            }
                            pointer.setByPointer(((Pointer) source));
                        } else {
                            pointer.setByVariable(source);
                        }
                    } else {
                        if (source != null && source instanceof Pointer) {
                            destination.setValeur(source.getValeur().toString());
                        } else if (destination instanceof Variable && listValues != null) {
                            destination.setValeur(listValues[0].getValeur().toString());
                        }
                    }
                    break;
                case eTypeDessalloc:
                    if (destination instanceof Pointer || destination instanceof Array) {
                        MemorySet pointer = (MemorySet) destination;
                        if (source == null) {
                            pointer.setByList(null);
                        }
                    }
                    break;
            }
            destination = variableDest;
            source = variableSource;
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return true;
    }

    /**
     * Annule une affectation en reinitialisant une variable
     */
    public void desaffect() {
        Variable variableDest = destination; /* sauvegarde la référence de la variable de destination*/
        destination = destination.getVariable(this.nameDest);
        switch (enumType.getTypeOf(typeid)) {
            case eTypePrimitif:
                destination.setValeur(sauvegarde.getValeur().toString());
                destination.produireComposant().setVisible(visibleComponent);
                destination.produireComposant().setForeground(sauvegarde.produireComposant().getForeground());
                break;
            case eTypeDessalloc:
            case eTypeArray:
            case eTypePointeur:
                if (destination instanceof Pointer || destination instanceof Array) {
                    MemorySet pointer = (MemorySet) destination;
                    if (listValues != null) {
                        pointer.setByList(null);
                    }
                    if (sauvegarde instanceof Pointer) {
                        pointer.setByPointer((Pointer) sauvegarde);
                    } else {
                        pointer.setByArray((Array) sauvegarde);
                    }
                } else if (destination instanceof Variable) {
                    destination.setValeur(sauvegarde.getValeur().toString());
                }
                destination.produireComposant().setForeground(sauvegarde.produireComposant().getForeground());
                destination.produireComposant().setVisible(visibleComponent);
                break;
        }
        destination = variableDest;
        //sauvegarde = null;
    }

    /**
     * Supprime une flèche d'un objet graphique à une autre représentant une
     * variable primitive.
     */
    public void removeFlecheTemporaire() {
        if (source != null) {
            Variable variableDest = destination.getVariable(this.nameDest);
            Variable variableSource = source.getVariable(this.nameSrc);
            if ("primitif".equals(typeid)) {
                ((OperationAdapter) variableDest.produireComposant()).removeReferer(variableSource.produireComposant());
            }
            variableSource.produireComposant().setForeground(Color.WHITE);
        }
    }

    @Override
    public Component produireComposant() {
        Variable variableDest = destination.getVariable(this.nameDest);
        return variableDest.produireComposant();
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.eTypeAffectation;
    }

}
