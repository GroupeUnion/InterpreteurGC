package xmlstructure;

import interpreteurgraphic.ArrayFigure;
import interpreteurgraphic.Composant;
import interpreteurgraphic.Label;
import interpreteurgraphic.OperationClass;
import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;
import xmlstructure.Variable.MemorySet;

/**
 * Objet contenant les informations d'un tableau
 *
 * @author mahamat
 */
public class Array extends Variable implements Serializable, MemorySet {

    /**
     * Liste des cases d'un tableau
     */
    protected Variable listCases[];
    /**
     * Indique si le tableau est un pointer ou un tableau static
     */
    private boolean isPointer;
    /**
     * Indique le nombre d'élément à l'initialisation d'un tableau
     */
    private int nbElement;
    /**
     * Objet graphique représentant un tableau
     */
    private ArrayFigure arrayfigure;
    /**
     * Objet graphique représentant le pointeur par défaut sur un tableau
     */
    private final Composant composant;

    /**
     * Constructeur d'un tableau selon une taille par défaut
     *
     * @param ident Identifiant de l'instruction
     * @param type Type d'un tableau
     * @param nom Nom de la variable
     * @param pointeur Indique si un tableau est dynamique ou non
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param count Taille par défaut du tableau
     */
    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, int count) {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        if (!this.isPointer) {
            this.nbElement = count;
            listCases = new Variable[nbElement];
            String typeCase = type.replaceAll("\\[\\]", "").trim();
            for (int i = 0; i < listCases.length; i++) {
                listCases[i] = new Variable(this.ident, typeCase, "[" + i + "]", "NOINIT", this.ligne, this.fichier);
            }
        }
        this.composant = new Composant(getType() + " " + nom);
    }

    /**
     * Constructeur d'un tableau selon une liste de variable initiale
     *
     * @param ident Identifiant de l'instruction
     * @param type Type d'un tableau
     * @param nom Nom d'un tableau
     * @param pointeur Indique si un tableau est dynamique ou non
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param listVariable Liste des valeurs initiales
     */
    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, List<Variable> listVariable) {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        this.nbElement = listVariable.size();
        this.listCases = new Variable[listVariable.size()];
        listVariable.toArray(this.listCases);
        this.composant = new Composant(getType() + " " + nom);
    }

    /**
     * Constructeur d'un tableau selon un modèle de variable, utilisé pour les
     * tableaux de structures
     *
     * @param ident Identifiant de l'instruction
     * @param type Type d'un tableau
     * @param nom Nom d'un tableau
     * @param pointeur Indique si un tableau est dynamique ou non
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     * @param modele Modèle de structure
     * @param count Taille par défaut du tableau
     * @throws IOException erreur sur le clonage du modèle de structure
     * @throws ClassNotFoundException erreur sur le clone du modèle de structure
     */
    public Array(String ident, String type, String nom, boolean pointeur,
            String ligne, String fichier, Structure modele, int count) throws IOException, ClassNotFoundException {
        super(ident, type, nom, "", ligne, fichier);
        this.isPointer = pointeur;
        this.nbElement = count;
        listCases = new Variable[nbElement];
        for (int i = 0; i < listCases.length; i++) {
            listCases[i] = modele.copie();
            listCases[i].setNom("[" + i + "]");
        }
        this.composant = new Composant(getType() + " " + nom);
    }

    /**
     * Renvoi une variable interne à un tableau selon son nom ex : variable
     * a[0][0] du tableau a
     *
     * @param name Nom de la variable
     * @param parent Nom de la structure de données contenant le tableau
     * @return Variable recherché
     */
    @Override
    public Variable getVariable(String name, String parent) {
        if (isPointer && listCases == null) {
            return null;
        }
        for (Variable variable : listCases) {
            String newParentName = variable.getNomComplet(parent);
            if (newParentName.equals(name)) {
                return variable;
            } else if ((variable = variable.getVariable(name, newParentName)) != null) {
                return variable;
            }
        }
        return null;
    }

    @Override
    public void setByPointer(Pointer p) {
    }

    @Override
    public void setByArray(Array array) {
        isPointer = array.isPointer;
        arrayfigure = array.arrayfigure;
        listCases = array.listCases;
        updateComposant();
    }

    @Override
    public void setByList(Variable[] listVariable) {
        if (listCases == null) {
            listCases = listVariable;
        } else {
            if (listVariable != null) {
                if (listCases.length < listVariable.length) {
                    listCases = new Variable[listVariable.length];
                }
                System.arraycopy(listVariable, 0, listCases, 0, listVariable.length);
            } else {
                listCases = null;
            }
        }
        this.updateComposant();
    }

    /*pointeur identique*/
    @Override
    public void setByVariable(Variable variable) {
        if (listCases == null || listCases.length > 1) {
            listCases = new Variable[1];
        }
        listCases[0] = variable;
        //listCases[0].setNom((isPointer) ? listCases[0].getNom() : "[0]");
        this.updateComposant();
    }

    @Override
    public void setPointer(boolean isPointer) {
        this.isPointer = isPointer;
    }

    public boolean isEmpty() {
        return listCases == null || listCases.length == 0;
    }

    @Override
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();
        ((Array) copied).arrayfigure = arrayfigure;
        out.close();
        bos.close();
        bis.close();
        in.close();
        return copied;
    }

    @Override
    public Component produireComposant() {
        if (arrayfigure == null) {
            arrayfigure = new ArrayFigure();
            if (listCases != null) {
                for (Variable variable : listCases) {
                    Component component = variable.produireComposant();
                    if (!isPointer) {
                        if (component instanceof Label) {
                            ((OperationClass.OperationAdapter) component).setHaveMargin(false);
                        }
                        component.setName(variable.getNom());
                        component.setVisible(true);

                        arrayfigure.addCase(component);
                        arrayfigure.addToList(component);
                    } else {
                        arrayfigure.addToList(component);
                    }
                }
            }
            if (!isPointer) {
                arrayfigure.addPointer(composant);
            }
            arrayfigure.setVisible(false);
        }
        return arrayfigure;
    }

    /**
     * Efface le contenu et reconstruit l'objet graphique représentant un
     * tableau.
     */
    public void updateComposant() {
        if (arrayfigure != null) {
            arrayfigure.removeAllCases();/* appelle l'éffacement des cases d'un tableau */
            /* Si le tableau n'est pas un pointeur, qu'il contient une liste de valeur et que l'objet graphique la représentant 
             est déplaçable alors on peut recontruire l'objet graphique. */

            if (listCases != null) {
                for (int i = 0; i < listCases.length; i++) {
                    Variable variable = listCases[i];
                    Component component = variable.produireComposant();
                    if (!isPointer && arrayfigure.isDeplacable()) {
                        if (component instanceof Label) {
                            ((OperationClass.OperationAdapter) component).setHaveMargin(false);
                        }
                        component.setVisible(true);
                        component.setName("[" + i + "]");
                        arrayfigure.addCase(component);
                        arrayfigure.addToList(component);
                    } else {
                        arrayfigure.addToList(component);
                    }
                }
            }
        }
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.eTypeArray;
    }

}
