/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreteurgraphic;

import java.awt.Component;
import java.awt.Container;
import java.util.EventListener;
import xmlstructure.Instruction;

/**
 *
 * @author Asus
 */
public class OperationClass {

    public interface OperationListener extends EventListener {

        public void componentEvent(Container c);
    }

    public interface OperationAdapter {

        public abstract void addOperationListener(OperationClass.OperationListener operation);

        public abstract void setHaveMargin(boolean haveMargin);

        public abstract void setMargin(int top, int left, int bottom, int right);

        public abstract void removeReferer(Component toReferer);

        public abstract void setToReferer(Component toReferer);

        public abstract void addReferer(Component toReferer);

        public abstract void setVisibleEvent(Instruction source, boolean isVisible);
        
    }
}
