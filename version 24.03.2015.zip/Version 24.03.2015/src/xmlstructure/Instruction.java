package xmlstructure;


import java.awt.Component;
import java.io.Serializable;
import javax.swing.event.EventListenerList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Instruction implements Serializable {

    protected String ident, ligne, fichier;

    public Instruction(String ident, String ligne, String fichier) {
        this.ident = ident;
        this.ligne = ligne;
        this.fichier = fichier;
    }

    public int getIdent() {
        return (ident==null)? -1 : Integer.parseInt(ident);
    }

    public int getLigne() {
        return (ident==null)? -1 : Integer.parseInt(ligne);
    }

    public String getFichier() {
        return fichier;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public void setLigne(String ligne) {
        this.ligne = ligne;
    }

    public void setFichier(String fichier) {
        this.fichier = fichier;
    }

    public Component produireComposant() {
        return null;
    }

}
