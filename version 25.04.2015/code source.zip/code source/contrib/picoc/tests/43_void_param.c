#include <stdio.h>

void fred(void)
{
    printf("yo\n");
}



void main() 
{
	fred();
}
