package interpreteurgraphic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.swing.JPanel;

/**
 *
 * @author Asus
 */
public class Fleche extends JPanel {

    private final Map<Component, List<Component>> listComponent;
    /*Tableau de hachage listant un objet graphique et tous les autres objets graphiques pointant vers elle.*/

    public Fleche() {
        listComponent = new HashMap<Component, List<Component>>();
        setOpaque(false); /*Rend l'objet graphique non opaque*/
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g); //To change body of generated methods, choose Tools | Templates.
        Container parent = this.getParent();
        this.setSize(parent.getSize());/*Prend les dimensions de son conteneur*/
        Graphics2D g2 = (Graphics2D) g;
        g.setColor(Color.WHITE);

        for (Map.Entry<Component, List<Component>> entry : listComponent.entrySet()) {
            Component fromControl = entry.getKey();
            /*Si l'objet graphique de départ (source de la flèche) est visible et présente sur la fenêtre principale */
            if (parent.isAncestorOf(fromControl) && fromControl.isShowing()) {
                Rectangle rectangleF = fromControl.getBounds(); /*Récuparation des positions et tailles*/
                for (Component toControl : entry.getValue()) {
                    /*Si l'objet graphique d'arrivé (destination de la flèche) est visible et présente sur la fenêtre principale
                    et que l'objet graphique de départ et celle d'arrivé ne sont pas parent l'une de l'autre.*/
                    if (parent.isAncestorOf(toControl) && toControl.isShowing()
                            && !((Container) fromControl).isAncestorOf(toControl)
                            && !((Container) toControl).isAncestorOf(fromControl)) {
                        Rectangle rectangleT = toControl.getBounds(); /*Récuparation des positions et tailles*/
                        Point2D centreF = new Point2D.Double(rectangleF.getCenterX(), rectangleF.getCenterY());
                        Point2D centreT = new Point2D.Double(rectangleT.getCenterX(), rectangleT.getCenterY());
//                        g.setColor(Color.ORANGE);
//                        g.fillRect((int) centreF.getX() - 3, (int) centreF.getY() - 3, 6, 6);
//                        g.setColor(Color.WHITE);
//                        g.fillRect((int) centreT.getX() - 3, (int) centreT.getY() - 3, 6, 6);
//
//                        g.fillRect((int) rectangleF.getX(), (int) rectangleF.getY(), (int) rectangleF.getWidth(), (int) rectangleF.getHeight());
//                        g.fillRect((int) rectangleT.getX(), (int) rectangleT.getY(), (int) rectangleT.getWidth(), (int) rectangleT.getHeight());
                        boolean coin = Math.abs(rectangleF.x - rectangleT.x) > rectangleF.width + 100
                                && Math.abs(rectangleF.y - rectangleT.y) > rectangleF.height + 100;
                        Point2D equaSegment;
                        Point2D pPoint1, pPoint2, pPoint3, pPoint4;
                        if (rectangleF.x >= rectangleT.x) {
                            if (rectangleF.y >= rectangleT.y) {
                                if (coin) {
                                    centreF = new Point2D.Double(rectangleF.x, rectangleF.y);
                                    centreT = new Point2D.Double(rectangleT.x + rectangleT.width, rectangleT.y + rectangleT.height);
                                }
                                equaSegment = equationDroite(centreF.getX(), centreF.getY(), centreT.getX(), centreT.getY());
                                pPoint1 = new Point2D.Double(rectangleF.x, rectangleF.x * equaSegment.getX() + equaSegment.getY());
                                pPoint2 = new Point2D.Double((rectangleF.y - equaSegment.getY()) / equaSegment.getX(), rectangleF.y);
                                pPoint3 = new Point2D.Double(rectangleT.x + rectangleT.width, (rectangleT.x + rectangleT.width) * equaSegment.getX() + equaSegment.getY());
                                pPoint4 = new Point2D.Double(((rectangleT.y + rectangleT.height) - equaSegment.getY()) / equaSegment.getX(), (rectangleT.y + rectangleT.height));
                            } else {
                                if (coin) {
                                    centreF = new Point2D.Double(rectangleF.x, rectangleF.y + rectangleF.height);
                                    centreT = new Point2D.Double(rectangleT.x + rectangleT.width, rectangleT.y);
                                }
                                equaSegment = equationDroite(centreF.getX(), centreF.getY(), centreT.getX(), centreT.getY());
                                pPoint1 = new Point2D.Double(rectangleF.x, rectangleF.x * equaSegment.getX() + equaSegment.getY());
                                pPoint2 = new Point2D.Double(((rectangleF.y + rectangleF.height) - equaSegment.getY()) / equaSegment.getX(), (rectangleF.y + rectangleF.height));
                                pPoint3 = new Point2D.Double(rectangleT.x + rectangleT.width, (rectangleT.x + rectangleT.width) * equaSegment.getX() + equaSegment.getY());
                                pPoint4 = new Point2D.Double((rectangleT.y - equaSegment.getY()) / equaSegment.getX(), rectangleT.y);
                            }
                        } else {
                            if (rectangleF.y >= rectangleT.y) {
                                if (coin) {
                                    centreT = new Point2D.Double(rectangleT.x, rectangleT.y + rectangleT.height);
                                    centreF = new Point2D.Double(rectangleF.x + rectangleF.width, rectangleF.y);
                                }
                                equaSegment = equationDroite(centreF.getX(), centreF.getY(), centreT.getX(), centreT.getY());
                                pPoint1 = new Point2D.Double(rectangleF.x + rectangleF.width, (rectangleF.x + rectangleF.width) * equaSegment.getX() + equaSegment.getY());
                                pPoint2 = new Point2D.Double((rectangleF.y - equaSegment.getY()) / equaSegment.getX(), rectangleF.y);
                                pPoint3 = new Point2D.Double(rectangleT.x, rectangleT.x * equaSegment.getX() + equaSegment.getY());
                                pPoint4 = new Point2D.Double(((rectangleT.y + rectangleT.height) - equaSegment.getY()) / equaSegment.getX(), (rectangleT.y + rectangleT.height));
                            } else {
                                if (coin) {
                                    centreT = new Point2D.Double(rectangleT.x, rectangleT.y);
                                    centreF = new Point2D.Double(rectangleF.x + rectangleF.width, rectangleF.y + rectangleF.height);
                                }
                                equaSegment = equationDroite(centreF.getX(), centreF.getY(), centreT.getX(), centreT.getY());
                                pPoint1 = new Point2D.Double(rectangleF.x + rectangleF.width, (rectangleF.x + rectangleF.width) * equaSegment.getX() + equaSegment.getY());
                                pPoint2 = new Point2D.Double(((rectangleF.y + rectangleF.height) - equaSegment.getY()) / equaSegment.getX(), (rectangleF.y + rectangleF.height));
                                pPoint3 = new Point2D.Double(rectangleT.x, rectangleT.x * equaSegment.getX() + equaSegment.getY());
                                pPoint4 = new Point2D.Double((rectangleT.y - equaSegment.getY()) / equaSegment.getX(), rectangleT.y);
                            }
                        }
                        rectangleF.setRect(rectangleF.x - 3, rectangleF.y - 3, rectangleF.width + 6, rectangleF.height + 6);
                        rectangleT.setRect(rectangleT.x - 3, rectangleT.y - 3, rectangleT.width + 6, rectangleT.height + 6);

//                        g.setColor(Color.BLUE);
//                        g.fillRect((int) pPoint1.getX() - 3, (int) pPoint1.getY() - 3, 6, 6);
//                        g.setColor(Color.RED);
//                        g.fillRect((int) pPoint2.getX() - 3, (int) pPoint2.getY() - 3, 6, 6);
//                        g.setColor(Color.YELLOW);
//                        g.fillRect((int) pPoint3.getX() - 3, (int) pPoint3.getY() - 3, 6, 6);
//                        g.setColor(Color.GREEN);
//                        g.fillRect((int) pPoint4.getX() - 3, (int) pPoint4.getY() - 3, 6, 6);
//                        g.setColor(Color.WHITE);
                        if (!rectangleF.contains(pPoint1)) {
                            pPoint1 = pPoint2;
                        }
                        if (!rectangleT.contains(pPoint3)) {
                            pPoint3 = pPoint4;
                        }
                        double angle = calculateAngle((int) pPoint1.getX(), (int) pPoint1.getY(), (int) pPoint3.getX(), (int) pPoint3.getY());
                        if (toControl instanceof Label && fromControl instanceof Label) {
                            drawDashedLine(g2, (int) pPoint1.getX(), (int) pPoint1.getY(), (int) pPoint3.getX(), (int) pPoint3.getY());
                        } else {
                            g.drawLine((int) pPoint1.getX(), (int) pPoint1.getY(), (int) pPoint3.getX(), (int) pPoint3.getY());
                        }
                        drawArrowHeadAtLocation(g2, (int) pPoint3.getX(), (int) pPoint3.getY(), angle);
                    }
                }
            }

        }
    }

    public void addFleche(Component fromControl, Component toControl) {
        List<Component> listC;
        if ((listC = listComponent.get(fromControl)) == null) {
            listC = new ArrayList<Component>();
            listComponent.put(fromControl, listC);
        }
        if (!listC.contains(toControl)) {
            listC.add(toControl);
        }
    }

    public void removeFlecheTo(Component toControl) {
        for (Iterator<Map.Entry<Component, List<Component>>> it = listComponent.entrySet().iterator(); it.hasNext();) {
            Map.Entry<Component, List<Component>> entry = it.next();
            List<Component> list = entry.getValue();
            list.remove(toControl);
            if (list.isEmpty()) {
                it.remove();
            }
        }
    }

    public void tracerLigne(Graphics g, Point2D from, Point2D to, Point2D eq) {
        double debut = (from.getX() < to.getX()) ? from.getX() : to.getX();
        double fin = (from.getX() < to.getX()) ? to.getX() : from.getX();

        for (; debut < fin; debut++) {
            g.drawOval((int) debut, (int) (debut * eq.getX() + eq.getY()), 2, 2);
        }
    }

    public void drawDashedLine(Graphics g, int x1, int y1, int x2, int y2) {

        //creates a copy of the Graphics instance
        Graphics2D g2d = (Graphics2D) g.create();
        Stroke dashed = new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{9}, 0);
        g2d.setStroke(dashed);
        g2d.drawLine(x1, y1, x2, y2);
        g2d.dispose();
    }

    public void removeFlecheFrom(Component fromControl) {
        listComponent.remove(fromControl);
    }

    public void removeFleche(Component fromControl, Component toControl) {
        for (Iterator<Map.Entry<Component, List<Component>>> it = listComponent.entrySet().iterator(); it.hasNext();) {
            Map.Entry<Component, List<Component>> entry = it.next();
            if (entry.getKey().equals(toControl)) {
                List<Component> list = entry.getValue();
                list.remove(fromControl);
                if (list.isEmpty()) {
                    it.remove();
                }
                break;
            }
        }
    }

    private double calculateAngle(double x1, double y1, double x2, double y2) {
        double a = (x2 - x1);
        double b = (y2 - y1);
        double length = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
        if (length == 0) {
            return 0;
        }
        double p = length; //Math.sqrt(a*a+b*b);
        double theta = Math.asin(Math.abs(b) / p);
        if (b < 0) {
            theta = -theta;
        }
        if (a < 0) {
            theta = Math.PI - theta;
        }
        // Rescale into [0, 2*PI[.
        theta %= 2 * Math.PI;
        if (theta < 0) {
            theta += 2 * Math.PI;
        }
        return theta;
    }

    private void drawArrowHeadAtLocation(Graphics2D graphics, double x, double y, double angle) {
        graphics.translate(x, y);
        graphics.rotate(angle);
        drawArrowHead(graphics);
        graphics.rotate(-angle);
        graphics.translate(-x, -y);
    }

    private void drawArrowHead(Graphics2D graphics) {

        int xPoints[] = {0, -10, -10};
        int yPoints[] = {0, 5, -5};
        graphics.fillPolygon(xPoints, yPoints, 3);
        //graphics.drawLine(0, 0, -10, 5);
        //graphics.drawLine(0, 0, -10, -5);
        //graphics.drawLine(-10, 5, -10, -5);
    }

    private Point2D equationDroite(double xz1, double yz1, double xz2, double yz2) {

        if (xz1 == xz2) {
            //return new Point2D.Double(xz1, 0);
            xz1+=0.01;
        }
        if (yz1 == yz2) {
            return new Point2D.Double(0, yz2);
        }
        double denominateur = (xz2 - xz1);
        double nominateur = (yz2 - yz1);
        double a = nominateur / denominateur;
        double y = a * xz1;
        double b = yz1 - y;
        return new Point2D.Double(a, b);

    }

    private Point2D getIntersection(Point2D equation1, Point2D equation2) {
        if (equation2.getX() != equation1.getX()) {
            double x1 = (equation1.getY() - equation2.getY()) / (equation2.getX() - equation1.getX());
            double y1 = x1 * equation1.getX() + equation1.getY();
            return new Point2D.Double(x1, y1);
        }
        return null;
    }

}
