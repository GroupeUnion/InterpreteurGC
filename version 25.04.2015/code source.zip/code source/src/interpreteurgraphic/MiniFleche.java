package interpreteurgraphic;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.border.Border;

/**
 * Objet graphique modélisant des petites flèches soulignant une instruction
 * active dans le gestionnaire de codes sources.
 *
 * @see SourcePanel
 * @author mahamat
 */
public class MiniFleche extends JLabel {

    private final Path2D.Double arrow = createArrow();
    private final double theta = 0;
    private Color col;

    /**
     * Constructeur de l'objet graphique
     *
     * @param col couleur de la flèche
     */
    public MiniFleche(Color col) {
        this.col = col;
    }

    /**
     * Renvoi la couleur de la flèche
     *
     * @return couleur de la flèche
     */
    public Color getCol() {
        return col;
    }

    /**
     * Modifie la couleur de la flèche
     *
     * @param col nouvelle couleur de la flèche
     */
    public void setCol(Color col) {
        this.col = col;
    }

    /**
     * Modifie la couleur de police
     *
     * @param fg nouvelle couleur de police
     */
    @Override
    public void setForeground(Color fg) {
        super.setForeground(fg); //To change body of generated methods, choose Tools | Templates.
        setCol(fg);
    }

    /**
     * Dessine une figure
     *
     * @param g objet graphique
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        int cx = getWidth() / 2;
        int cy = getHeight() / 2;
        AffineTransform at = AffineTransform.getTranslateInstance(cx - 8, cy);
        at.rotate(theta);
        at.scale(2.0, 2.0);
        Shape shape = at.createTransformedShape(arrow);
        g2.setPaint(col);
        g2.draw(shape);
    }

    /**
     * Renvoi une figure graphique modélisant une flèche
     *
     * @return structure de données contenant les positions des tracés.
     */
    private Path2D.Double createArrow() {
        int length = 10;
        int barb = 3;
        double angle = Math.toRadians(20);
        Path2D.Double path = new Path2D.Double();
        path.moveTo(-length / 2, 0);
        path.lineTo(length / 2, 0);
        double x = length / 2 - barb * Math.cos(angle);
        double y = barb * Math.sin(angle);
        path.lineTo(x, y);
        x = length / 2 - barb * Math.cos(-angle);
        y = barb * Math.sin(-angle);
        path.moveTo(length / 2, 0);
        path.lineTo(x, y);
        return path;
    }

    /**
     * Modifie la marge de l'objet graphique
     *
     * @param top taille de la marge en haut
     * @param left taille de la marge à gauche
     * @param bottom taille de la marge en bas
     * @param right taille de la marge à droite
     */
    public void setMargin(int top, int left, int bottom, int right) {
        Border margin = BorderFactory.createEmptyBorder(top, left, bottom, right);
        this.setBorder(margin);
    }

}
