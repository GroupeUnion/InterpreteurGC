package interpreteurgraphic;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * Objet graphique gestionnaire de codes sources.
 * @author mahamat
 */
public class SourcePanel extends JPanel implements ListSelectionListener {

    private final int rowHeight = 20; /* haute des cellules */
    private final List<JList> listePanel; /*Liste des objets graphiques contenant les instructions d'un fichier C*/
    private final JTabbedPane pagePanel; /**/
    private final AtomicInteger numSuivant, numPrecedent; /**/
    private final StringBuilder fichierPrecedent, fichierSuivant; /**/

    /**
     * Contructeur du gestionnaire de codes sources
     * @param fichierSource liste des chemins d'accès des fichiers C.
     */
    public SourcePanel(String fichierSource[]) {
        this.listePanel = new ArrayList<JList>();
        this.pagePanel = new JTabbedPane();
        this.setLayout(new BorderLayout());
        this.pagePanel.setLocation(40, 0);
        this.pagePanel.getAccessibleContext().setAccessibleDescription("");
        this.numSuivant = new AtomicInteger(0);
        this.numPrecedent = new AtomicInteger(0);
        this.fichierPrecedent = new StringBuilder("");
        this.fichierSuivant = new StringBuilder("");
        for (String string : fichierSource) {
            addFichier(string);
        }
        this.add(pagePanel, BorderLayout.CENTER);
    }

    /**
     * Crée un objet graphique contenant les instructions du fichier C.
     * @param fichier_src chemin d'accès du fichier C.
     */
    protected void addFichier(String fichier_src) {
        try {
            File file = new File(fichier_src);
            if (!file.exists()) {
                return;
            }
            List<String> lines = Files.readAllLines(file.toPath(), Charset.forName("UTF-8"));
            JList<String> newList = new JList<String>(lines.toArray(new String[lines.size()]));
            JScrollPane scroll = new JScrollPane(newList, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            newList.setBackground(new Color(109, 170, 193));
            newList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            newList.setFixedCellHeight(rowHeight);

            pagePanel.addTab(file.getName(), scroll);
            newList.setSelectedValue(null, true);
            newList.addListSelectionListener(this);
            listePanel.add(newList);
            newList.setCellRenderer(new MyListCellRenderer(file.getName(), numPrecedent, fichierPrecedent));
            newList.setName(file.getName());
        } catch (IOException ex) {
        }

    }

    
    /**
     * Met à jour les flèches suivantes et précédentes
     * @param numPrec numéro de ligne de l'instruction précedente
     * @param nomFichierPrec fichier source de l'instruction précedente
     * @param numSuiv numéro de ligne de l'instruction suivante
     * @param nomFichierSuiv fichier source de l'instruction suivante
     */
    public void update(int numPrec, String nomFichierPrec, int numSuiv, String nomFichierSuiv) {        
        if (numSuiv != -1) {
            this.numSuivant.set(numSuiv);
            this.fichierSuivant.delete(0, this.fichierSuivant.length());
            this.fichierSuivant.append(nomFichierSuiv);
            if (numPrec != -1) {
                this.numPrecedent.set(numPrec);
                this.fichierPrecedent.delete(0, this.fichierPrecedent.length());
                this.fichierPrecedent.append(nomFichierPrec);
                int pagePrec = this.pagePanel.indexOfTab(nomFichierPrec);
                listePanel.get(pagePrec).clearSelection();
            }
            listePanel.get(this.pagePanel.indexOfTab(nomFichierSuiv)).setSelectedIndex(numSuiv);
            pagePanel.setSelectedIndex(this.pagePanel.indexOfTab(nomFichierSuiv));
        }
    }
    
    /**
     * Modifie la taille de l'objet graphique
     * @param width largeur de l'objet graphique
     * @param height hauteur de l'objet graphique
     */

    @Override
    public void setSize(int width, int height) {
        super.setSize(width, height - 15);
        if (this.pagePanel != null) {
            this.pagePanel.setSize(width, height - 15);
            this.pagePanel.setLocation(0, 0);
        }
    }

    /**
     * Signal la modification de la selection d'une cellule.
     * @param e indique l'ancien et la nouvelle cellule selectionné.
     */
    @Override
    public void valueChanged(ListSelectionEvent e) {
        JList lsm = (JList) e.getSource();
        boolean isFichierSuivant, isFichierPrecedent = false;
        if (((isFichierSuivant = fichierSuivant.toString().equals(lsm.getName())) &&  !lsm.isSelectedIndex(this.numSuivant.get()) )
                || ((isFichierPrecedent = fichierPrecedent.toString().equals(lsm.getName())) && !lsm.isSelectedIndex(this.numPrecedent.get()))
                || (!isFichierSuivant && !isFichierPrecedent)) {
            if (isFichierSuivant) {
                lsm.setSelectedIndex(numSuivant.get());
            } else {
                lsm.clearSelection();
            }
        }
    }
}

/**
 * objet graphique design d'une cellule
 * @author mahamat
 */
class MyListCellRenderer extends JPanel implements ListCellRenderer {

    private final MiniFleche miniFleche;
    private final JLabel numLigne, codeSource;
    private final Color selectedColor, unSelectedColor; /*Couleur d'une cellule selectionné et d'une cellule non selectionné*/
    private final StringBuilder fichierPrecedent;
    private final AtomicInteger numPrecedent;
    private final String fichierRender;

    /**
     * Constructeur de l'objet graphique
     * @param fichierRender fichier source de l'instruction représenté par la cellule.
     * @param numPrecedent référence sur numéro de l'instruction précedente
     * @param fichierPrecedent référence sur le fichier de linstruction précedenete
     */
    public MyListCellRenderer(String fichierRender, AtomicInteger numPrecedent, StringBuilder fichierPrecedent) {
        this.setOpaque(true);
        this.fichierRender = fichierRender;
        this.numPrecedent = numPrecedent;
        this.fichierPrecedent = fichierPrecedent;
        this.selectedColor = new Color(184, 207, 229);
        this.unSelectedColor = new Color(109, 170, 193);

        this.miniFleche = new MiniFleche(Color.BLACK);
        this.miniFleche.setMargin(0, 2, 0, 0);
        this.miniFleche.setSize(30, 20);
        this.miniFleche.setPreferredSize(new Dimension(30, 20));
        this.miniFleche.setLocation(5, 0);

        this.numLigne = new JLabel();
        this.numLigne.setSize(40, 20);
        this.numLigne.setPreferredSize(new Dimension(40, 20));
        this.numLigne.setLocation(30, 0);

        this.codeSource = new JLabel();
        this.codeSource.setLocation(70, 0);
        this.codeSource.setBorder(BorderFactory.createEmptyBorder(0, 70, 0, 0));
        
        this.setLayout(new BorderLayout());
        this.add(this.miniFleche);
        this.add(this.numLigne);
        this.add(this.codeSource);
                
    }
    
    /**
     * Modifie le rendu graphique de la cellule selon les caractéristiques du gestionnaire de codes sources.
     * @see SourcePanel
     * @param paramlist objet graphique parent de la cellule
     * @param value valeur de la cellule
     * @param index position de la cellule
     * @param isSelected indique si la cellule est selectionné
     * @param cellHasFocus indique si la cellule à le focus
     * @return composant modifié
     */

    @Override
    public Component getListCellRendererComponent(JList paramlist, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        numLigne.setText(String.valueOf(index + 1));
        codeSource.setText(value.toString());
        if (!isSelected) {
            this.setBackground(this.unSelectedColor);
            if (fichierPrecedent.toString().equals(fichierRender)
                    && numPrecedent.get() == index && numPrecedent.get() != 0) {
                this.miniFleche.setVisible(true);
                this.miniFleche.setCol(Color.WHITE);
            } else {
                this.miniFleche.setVisible(false);
                this.miniFleche.setCol(unSelectedColor);
            }
        } else {
            this.setBackground(selectedColor);
            this.miniFleche.setVisible(true);
            this.miniFleche.setCol(Color.BLACK);            
        }

        return this;
    }
}
