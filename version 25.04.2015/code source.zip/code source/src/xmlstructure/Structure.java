package xmlstructure;

import interpreteurgraphic.Composant;
import interpreteurgraphic.Label;
import interpreteurgraphic.OperationClass;
import interpreteurgraphic.WrapLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Objet contenant les informations d'une structure
 *
 * @author mahamat
 */
public class Structure extends Variable implements Serializable {

    /**
     * Objet graphique représentant une structure
     */
    private Composant composant;

    /**
     * Liste des membres d'une structure
     */
    private final List<Variable> listMembres;

    /**
     * Constructeur d'une structure
     *
     * @param ident Identifiant de l'instruction
     * @param type Type de la structure
     * @param nom Nom d'une structure
     * @param ligne Ligne de l'instruture
     * @param fichier Fichier source de l'instruction
     */
    public Structure(String ident, String type, String nom, String ligne, String fichier) {
        super(ident, type, nom, "", ligne, fichier);
        listMembres = new ArrayList<Variable>();
    }

    @Override
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();
        ((Structure) copied).composant = composant;
        out.close();
        bos.close();
        bis.close();
        in.close();
        return copied;
    }

    /**
     * Ajoute un membre à la structure
     *
     * @param membre Nouveau membre de la structure
     */
    public void addMembre(Variable membre) {
        listMembres.add(membre);
    }

    /**
     * Efface les membres d'une structure
     */
    public void clearMembre() {
        listMembres.clear();
    }

    @Override
    public Variable getVariable(String name, String parent) {
        for (Variable variable : listMembres) {
            String newParentName = variable.getNomComplet(parent);
            if (newParentName.equals(name)) {
                return variable;
            } else if ((variable = variable.getVariable(name, newParentName)) != null) {
                return variable;
            }
        }
        return null;
    }

    @Override
    public Component produireComposant() {
        if (composant == null) {
            OperationClass.OperationAdapter operation;
            composant = new Composant(getType() + " " + getNom());
            composant.setLayout(new WrapLayout(FlowLayout.LEFT));
            for (Variable variable : listMembres) {
                Component component = variable.produireComposant();
                operation = (OperationClass.OperationAdapter) component;
                component.setVisible(true);
                operation.setHaveMargin(false);
                operation.setMargin(0, 0, 0, 0);
                composant.add(component);
            }
            composant.setBordBold(true);
        }
        return composant;
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.eTypeStructure;
    }
}
