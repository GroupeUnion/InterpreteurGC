package xmlstructure;

import interpreteurgraphic.Label;
import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * Objet contenant les informations d'une variable primitive
 *
 * @author mahamat
 */
public class Variable extends Instruction implements Serializable {

    /**
     * Type d'une variable
     */
    protected String type;
    /**
     * Nom d'une variable
     */
    protected String nom;
    /**
     * Reférence sur la valeur d'une variable
     */
    private StringBuilder valeur;
    /**
     * Objet graphique représentant une variable
     */
    private Label label;

    /**
     * Interface de gestion des modifications sur pointeur et tableau
     */
    public interface MemorySet {

        /**
         * Modifie les variables d'un tableau ou pointeur par une nouvelle liste
         * de variable
         *
         * @param listVariable Nouvelle liste de variable
         */
        public void setByList(Variable[] listVariable);

        /**
         * Modifie les variables d'un tableau ou pointeur par une nouvelle liste
         * de variable contenu dans un pointeur
         *
         * @param p Pointeur contenant la nouvelle liste
         */
        public void setByPointer(Pointer p);

        /**
         * Modifie la variable d'un pointeur par une nouvelle variable
         *
         * @param variable Nouvelle variable
         */
        public void setByVariable(Variable variable);

        /**
         * Modifie les variables d'un tableau ou pointeur par une nouvelle liste
         * de variable contenu dans un tableau
         *
         * @param array tableau contenant la nouvelle liste
         */
        public void setByArray(Array array);

        /**
         * Modifie le comportement d'un tableau ou pointeur lors de la mise à
         * jour de l'objet graphique la représentant.
         *
         * @param isPointer Comportement dynamique ou static
         */
        public void setPointer(boolean isPointer);

        /**
         * Indique si un tableau est vide
         * @return Etat du tableau
         */
        public boolean isEmpty();

    }

    /**
     * Constructeur par défaut d'une variable
     */
    public Variable() {
        super(null, null, null);
    }

    /**
     * Constructeur d'une variable
     *
     * @param ident Identifiant de l'instruction
     * @param type Type de la variable
     * @param nom Nom de la variable
     * @param valeur Valeur de la variable
     * @param ligne Ligne de l'instruction
     * @param fichier Fichier source de l'instruction
     */
    public Variable(String ident, String type, String nom, String valeur,
            String ligne, String fichier) {
        super(ident, ligne, fichier);
        this.nom = nom;
        this.type = type;
        this.valeur = new StringBuilder(!"null".equals(valeur) ? valeur : "NOINIT");
    }

    /**
     * Renvoi le type d'une variable
     *
     * @return Type d'une variable
     */
    public String getType() {
        return this.type;
    }

    /**
     * Renvoi la valeur d'une variable
     *
     * @return Référence d'une variable
     */
    public StringBuilder getValeur() {
        return this.valeur;
    }

    /**
     * Renvoi le nom d'une variable
     *
     * @return Nom d'une variable
     */
    public String getNom() {
        return this.nom;
    }

    /**
     * Modifie le nom d'une variable
     *
     * @param nom Nouveau nom d'une variable
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Modifie la valeur d'une variable
     *
     * @param valeur Nouvelle valeur d'une variable
     */
    public void setValeur(String valeur) {
        this.valeur.delete(0, this.valeur.length());
        this.valeur.append(valeur);
    }

    /**
     * Clone une variable
     *
     * @return Clone de la variable
     * @throws IOException Déclanché en cas d'erreur de clonage
     * @throws ClassNotFoundException Déclanché en cas d'erreur de clonage
     */
    public Variable copie() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(this);
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bis);
        Variable copied = (Variable) in.readObject();
        copied.label = label;
        out.close();
        bos.close();
        bis.close();
        in.close();
        return copied;
    }

    /**
     * Renvoi une concatenation entre le nom relative d'une variable et le nom
     * de la structure de données la contenant
     *
     * @param parent Nom de la structure de données parent
     * @return Nom absolue de la variable
     */
    public String getNomComplet(String parent) {
        if (this.nom == null || "".equals(this.nom)) {
            if (parent == null) {
                return "";
            }
            return parent;
        }
        return (parent != null) ? this.nom.contains("[") ? parent + this.nom
                : parent + "." + this.nom
                : this.nom;
    }

    /**
     * Renvoi l'instance courante si le nom de la variable recherché correspond
     * au nom de la variable et null sinon.
     *
     * @param name Nom de la variable recherché
     * @return Instance de variable courante ou null
     */
    public Variable getVariable(String name) {
        if (this.nom.equals(name)) {
            return this;
        }
        return getVariable(name, this.getNomComplet(null));
    }

    /**
     * Renvoi null
     *
     * @param name Nom de la variable recherché
     * @param parent Nom de la structure de données parent
     * @return null
     */
    public Variable getVariable(String name, String parent) {
        return null;
    }

    @Override
    public Component produireComposant() {
        if (label == null) {
            this.label = new Label(valeur, type + " " + nom);
            this.label.setVisible(false);
        }
        return label;
    }

    @Override
    public enumType getTypeInstruction() {
        return enumType.eTypeVariable;
    }
}
